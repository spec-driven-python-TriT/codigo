(function () {
  'use strict';

  var S = window.RealtorStorage;
  var KEY = S.KEYS.TENANTS;

  function getAll() {
    return S.getAll(KEY);
  }

  function getById(id) {
    return S.getById(KEY, id);
  }

  function validate(data) {
    var errors = {};
    if (!data.name || !String(data.name).trim()) errors.name = 'El nombre es requerido';
    if (!data.email || !String(data.email).trim()) {
      errors.email = 'El email es requerido';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(data.email))) {
      errors.email = 'Email inválido';
    }
    if (!data.phone || !String(data.phone).trim()) errors.phone = 'El teléfono es requerido';
    if (!data.documentId || !String(data.documentId).trim()) errors.documentId = 'El documento de identidad es requerido';
    return Object.keys(errors).length ? errors : null;
  }

  function create(data) {
    var now = new Date().toISOString();
    var tenant = {
      id: S.generateId(),
      name: String(data.name).trim(),
      email: String(data.email).trim(),
      phone: String(data.phone).trim(),
      documentId: String(data.documentId).trim(),
      notes: String(data.notes || '').trim(),
      createdAt: now,
      updatedAt: now
    };
    return S.create(KEY, tenant);
  }

  function update(id, data) {
    var updates = {
      name: String(data.name).trim(),
      email: String(data.email).trim(),
      phone: String(data.phone).trim(),
      documentId: String(data.documentId).trim(),
      notes: String(data.notes || '').trim(),
      updatedAt: new Date().toISOString()
    };
    return S.update(KEY, id, updates);
  }

  function remove(id) {
    S.remove(KEY, id);
  }

  window.RealtorTenants = {
    getAll: getAll,
    getById: getById,
    validate: validate,
    create: create,
    update: update,
    remove: remove
  };

}());
