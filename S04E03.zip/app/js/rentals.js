(function () {
  'use strict';

  var S = window.RealtorStorage;
  var KEY = S.KEYS.RENTALS;

  function getAll() {
    return S.getAll(KEY);
  }

  function getById(id) {
    return S.getById(KEY, id);
  }

  function getByPropertyId(propertyId) {
    var all = getAll();
    var result = [];
    for (var i = 0; i < all.length; i++) {
      if (all[i].propertyId === propertyId) result.push(all[i]);
    }
    return result;
  }

  function getActiveRental(propertyId) {
    var rentals = getByPropertyId(propertyId);
    for (var i = 0; i < rentals.length; i++) {
      if (rentals[i].contractStatus === S.CONTRACT_STATUS.ACTIVE) return rentals[i];
    }
    return null;
  }

  function validate(data) {
    var errors = {};
    if (!data.propertyId) errors.propertyId = 'Selecciona una propiedad';
    if (!data.tenantId) errors.tenantId = 'Selecciona un inquilino';
    if (!data.startDate) errors.startDate = 'La fecha de inicio es requerida';
    if (!data.endDate) errors.endDate = 'La fecha de fin es requerida';
    if (data.startDate && data.endDate && data.endDate <= data.startDate) {
      errors.endDate = 'La fecha de fin debe ser posterior al inicio';
    }
    if (!data.rentAmount || isNaN(data.rentAmount) || Number(data.rentAmount) <= 0) {
      errors.rentAmount = 'El monto de renta debe ser mayor a 0';
    }
    return Object.keys(errors).length ? errors : null;
  }

  function create(data) {
    var rental = {
      id: S.generateId(),
      propertyId: data.propertyId,
      tenantId: data.tenantId,
      startDate: data.startDate,
      endDate: data.endDate,
      rentAmount: Number(data.rentAmount),
      contractStatus: data.contractStatus || S.CONTRACT_STATUS.ACTIVE,
      createdAt: new Date().toISOString()
    };
    S.create(KEY, rental);
    S.update(S.KEYS.PROPERTIES, data.propertyId, {
      status: S.PROPERTY_STATUS.RENTED,
      updatedAt: new Date().toISOString()
    });
    return rental;
  }

  function endRental(id) {
    var rental = getById(id);
    if (!rental) return null;
    S.update(KEY, id, { contractStatus: S.CONTRACT_STATUS.ENDED });
    S.update(S.KEYS.PROPERTIES, rental.propertyId, {
      status: S.PROPERTY_STATUS.AVAILABLE,
      updatedAt: new Date().toISOString()
    });
    return rental;
  }

  window.RealtorRentals = {
    getAll: getAll,
    getById: getById,
    getByPropertyId: getByPropertyId,
    getActiveRental: getActiveRental,
    validate: validate,
    create: create,
    endRental: endRental
  };

}());
