# Tasks — Manage Rentas

- [x] Crear `pages/rent-property.html` con formulario validado
- [x] Mostrar contexto de la propiedad seleccionada (imagen, título, dirección)
- [x] Implementar `js/rentals.js` con `createRental` y consistencia de estado
- [x] Cambiar estado de la propiedad a `rentada` al registrar renta activa
- [x] Validar campos obligatorios y fechas antes de persistir
- [x] Mostrar confirmación previa y mensaje de éxito/error
- [x] Reemplazar input de `tenantName` por dropdown de inquilinos existentes
- [x] Persistir `tenantId` en lugar de `tenantName` en cada renta
- [x] Advertir al usuario si la propiedad seleccionada ya tiene un contrato activo
