# Tasks - Manage Properties

- [x] Crear `pages/properties.html` con listado
- [x] Crear `pages/add-property.html` con formulario validado
- [x] Crear `pages/edit-property.html` con carga de datos existentes
- [x] Implementar `js/properties.js` con CRUD, validaciones y filtro por estado
- [x] Implementar `validateProperty(data)` para centralizar reglas de validación
- [x] Renderizar grid de 3 columnas en escritorio con adaptación responsive
- [x] Mantener altura uniforme del header de cada card
- [x] Mantener alineación consistente de precio y acción principal entre cards
- [x] Implementar badges de estado
- [x] Mostrar mensajes de éxito/error y confirmaciones
- [x] Validar campos obligatorios antes de persistir
- [x] Mostrar estado vacío cuando no hay resultados de filtro
- [x] Asignar imagen real determinista a cada propiedad nueva si no se proporciona