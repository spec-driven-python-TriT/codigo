(function () {
  'use strict';

  var S = window.RealtorStorage;
  var KEY = S.KEYS.TENANTS;

  function getAll() {
    return S.getTenants ? S.getTenants() : S.getAll(KEY);
  }

  function getById(id) {
    return S.getById(KEY, id);
  }

  function findByDocumentId(documentId) {
    if (!documentId) return null;
    var normalized = String(documentId).trim().toLowerCase();
    var tenants = getAll();
    for (var i = 0; i < tenants.length; i++) {
      if (String(tenants[i].documentId || '').trim().toLowerCase() === normalized) return tenants[i];
    }
    return null;
  }

  function listTenants(filters) {
    var criteria = filters || {};
    var list = getAll();
    var search = String(criteria.search || '').trim().toLowerCase();
    if (!search) return list;

    var out = [];
    for (var i = 0; i < list.length; i++) {
      if (String(list[i].name || '').toLowerCase().indexOf(search) !== -1) out.push(list[i]);
    }
    return out;
  }

  function validateTenant(data, options) {
    var payload = data || {};
    var opts = options || {};
    var errors = {};
    if (!payload.name || !String(payload.name).trim()) errors.name = 'El nombre es requerido';
    if (!payload.email || !String(payload.email).trim()) {
      errors.email = 'El email es requerido';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(payload.email).trim())) {
      errors.email = 'Email inválido';
    }
    if (!payload.phone || !String(payload.phone).trim()) errors.phone = 'El teléfono es requerido';
    if (!payload.documentId || !String(payload.documentId).trim()) {
      errors.documentId = 'El documento de identidad es requerido';
    } else {
      var existing = findByDocumentId(payload.documentId);
      if (existing && existing.id !== opts.excludeId) {
        errors.documentId = 'Ya existe un inquilino con ese documento';
      }
    }

    return Object.keys(errors).length ? errors : null;
  }

  function createTenant(data) {
    var tenant = S.buildTenantRecord(data);
    return S.create(KEY, tenant);
  }

  function updateTenant(id, data) {
    var updates = {
      name: String(data.name).trim(),
      email: String(data.email).trim(),
      phone: String(data.phone).trim(),
      documentId: String(data.documentId).trim(),
      notes: String(data.notes || '').trim(),
      updatedAt: new Date().toISOString()
    };
    return S.update(KEY, id, updates);
  }

  function remove(id) {
    S.remove(KEY, id);
  }

  window.RealtorTenants = {
    createTenant: createTenant,
    updateTenant: updateTenant,
    getTenantById: getById,
    listTenants: listTenants,
    findByDocumentId: findByDocumentId,
    validateTenant: validateTenant,

    // Compatibilidad con API existente
    getAll: getAll,
    getById: getById,
    validate: validateTenant,
    create: createTenant,
    update: updateTenant,
    remove: remove
  };

}());
