(function () {
  'use strict';

  var KEYS = {
    PROPERTIES: 'realtor.properties',
    TENANTS: 'realtor.tenants',
    RENTALS: 'realtor.rentals',
    FLASH: 'realtor.flash'
  };

  var PROPERTY_STATUS = {
    AVAILABLE: 'disponible',
    RENTED: 'rentada',
    MAINTENANCE: 'en mantenimiento'
  };

  var CONTRACT_STATUS = {
    ACTIVE: 'activo',
    PENDING: 'pendiente',
    ENDED: 'finalizado'
  };

  function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  function createSeedPhotoUrl(id) {
    return 'https://picsum.photos/seed/' + id + '/800/500';
  }

  function nowIso() {
    return new Date().toISOString();
  }

  function read(key) {
    try {
      var raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function write(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function buildTenantRecord(data, overrides) {
    var payload = data || {};
    var now = nowIso();
    var base = {
      id: generateId(),
      name: String(payload.name || '').trim(),
      email: String(payload.email || '').trim(),
      phone: String(payload.phone || '').trim(),
      documentId: String(payload.documentId || '').trim(),
      notes: String(payload.notes || '').trim(),
      createdAt: now,
      updatedAt: now
    };
    return Object.assign(base, overrides || {});
  }

  /* ===== SEED DATA ===== */
  var SEED_PROPERTIES = [
    {
      id: 'p1', title: 'Apartamento Moderno Centro',
      address: 'Av. Reforma 200, Cuauhtémoc, CDMX', price: 15000,
      description: 'Espacioso apartamento con excelente vista y luz natural. Incluye estacionamiento y acceso a áreas comunes.',
      status: PROPERTY_STATUS.AVAILABLE, bedrooms: 2, bathrooms: 2,
      image: createSeedPhotoUrl('p1'), createdAt: nowIso(), updatedAt: nowIso()
    },
    {
      id: 'p2', title: 'Casa Familiar Polanco',
      address: 'Molière 45, Polanco, Miguel Hidalgo, CDMX', price: 28000,
      description: 'Casa de 3 pisos en zona residencial de alto nivel. Jardín privado, terraza y cochera para dos autos.',
      status: PROPERTY_STATUS.RENTED, bedrooms: 4, bathrooms: 3,
      image: createSeedPhotoUrl('p2'), createdAt: nowIso(), updatedAt: nowIso()
    },
    {
      id: 'p3', title: 'Loft Industrial Roma Norte',
      address: 'Álvaro Obregón 100, Roma Norte, Cuauhtémoc, CDMX', price: 18500,
      description: 'Loft con techos altos de 4 m, estilo industrial chic. Perfecto para profesionales creativos.',
      status: PROPERTY_STATUS.RENTED, bedrooms: 1, bathrooms: 1,
      image: createSeedPhotoUrl('p3'), createdAt: nowIso(), updatedAt: nowIso()
    },
    {
      id: 'p4', title: 'Departamento Luminoso Condesa',
      address: 'Amsterdam 23, Condesa, Cuauhtémoc, CDMX', price: 22000,
      description: 'Departamento luminoso frente al parque. Excelente ubicación con restaurantes y servicios a pie.',
      status: PROPERTY_STATUS.AVAILABLE, bedrooms: 2, bathrooms: 2,
      image: createSeedPhotoUrl('p4'), createdAt: nowIso(), updatedAt: nowIso()
    },
    {
      id: 'p5', title: 'Suite Ejecutiva Santa Fe',
      address: 'Paseo de los Tamarindos 60, Santa Fe, Álvaro Obregón, CDMX', price: 32000,
      description: 'Suite de lujo en zona corporativa. Vista panorámica a la ciudad. En renovación de baños.',
      status: PROPERTY_STATUS.MAINTENANCE, bedrooms: 1, bathrooms: 1,
      image: createSeedPhotoUrl('p5'), createdAt: nowIso(), updatedAt: nowIso()
    },
    {
      id: 'p6', title: 'Penthouse Coyoacán',
      address: 'Francisco Sosa 180, Del Carmen, Coyoacán, CDMX', price: 45000,
      description: 'Penthouse de lujo con terraza amplia y jardín elevado en zona histórica y tranquila.',
      status: PROPERTY_STATUS.AVAILABLE, bedrooms: 3, bathrooms: 3,
      image: createSeedPhotoUrl('p6'), createdAt: nowIso(), updatedAt: nowIso()
    }
  ];

  var SEED_TENANTS = [
    {
      id: 't1', name: 'Carlos Méndez Ruiz',
      email: 'carlos.mendez@email.com', phone: '55-1234-5678',
      documentId: 'MERC850302', notes: 'Inquilino puntual. Trabaja en sector financiero.',
      createdAt: nowIso(), updatedAt: nowIso()
    },
    {
      id: 't2', name: 'Ana Sofía González López',
      email: 'ana.gonzalez@email.com', phone: '55-9876-5432',
      documentId: 'GOLA920714', notes: 'Excelente historial de pagos. Diseñadora gráfica independiente.',
      createdAt: nowIso(), updatedAt: nowIso()
    },
    {
      id: 't3', name: 'Marco Antonio Reyes Vega',
      email: 'marco.reyes@email.com', phone: '55-5555-7890',
      documentId: 'REVM880121', notes: 'Ingeniero de software. Muy cuidadoso con las propiedades.',
      createdAt: nowIso(), updatedAt: nowIso()
    }
  ];

  var SEED_RENTALS = [
    {
      id: 'r1', propertyId: 'p2', tenantId: 't1',
      startDate: '2025-01-01', endDate: '2026-01-01', rentAmount: 28000,
      contractStatus: CONTRACT_STATUS.ACTIVE, createdAt: nowIso()
    },
    {
      id: 'r2', propertyId: 'p3', tenantId: 't2',
      startDate: '2025-03-01', endDate: '2026-03-01', rentAmount: 18500,
      contractStatus: CONTRACT_STATUS.ACTIVE, createdAt: nowIso()
    },
    {
      id: 'r3', propertyId: 'p4', tenantId: 't3',
      startDate: '2024-06-01', endDate: '2024-12-31', rentAmount: 20000,
      contractStatus: CONTRACT_STATUS.ENDED, createdAt: nowIso()
    }
  ];

  function ensureSeedData() {
    if (!read(KEYS.PROPERTIES)) write(KEYS.PROPERTIES, SEED_PROPERTIES);
    if (!read(KEYS.TENANTS))    write(KEYS.TENANTS,    SEED_TENANTS);
    if (!read(KEYS.RENTALS))    write(KEYS.RENTALS,    SEED_RENTALS);
  }

  function getTenants() {
    return getAll(KEYS.TENANTS);
  }

  function saveTenants(tenants) {
    write(KEYS.TENANTS, tenants || []);
    return getTenants();
  }

  /* ===== FLASH ===== */
  function setFlash(message, type) {
    write(KEYS.FLASH, { message: message, type: type || 'success' });
  }

  function getFlash() {
    var flash = read(KEYS.FLASH);
    localStorage.removeItem(KEYS.FLASH);
    return flash;
  }

  /* ===== GENERIC CRUD ===== */
  function getAll(key) {
    return read(key) || [];
  }

  function getById(key, id) {
    var items = getAll(key);
    for (var i = 0; i < items.length; i++) {
      if (items[i].id === id) return items[i];
    }
    return null;
  }

  function create(key, data) {
    var items = getAll(key);
    items.push(data);
    write(key, items);
    return data;
  }

  function update(key, id, data) {
    var items = getAll(key);
    for (var i = 0; i < items.length; i++) {
      if (items[i].id === id) {
        items[i] = Object.assign({}, items[i], data);
        write(key, items);
        return items[i];
      }
    }
    return null;
  }

  function remove(key, id) {
    var items = getAll(key);
    var filtered = [];
    for (var i = 0; i < items.length; i++) {
      if (items[i].id !== id) filtered.push(items[i]);
    }
    write(key, filtered);
  }

  window.RealtorStorage = {
    KEYS: KEYS,
    PROPERTY_STATUS: PROPERTY_STATUS,
    CONTRACT_STATUS: CONTRACT_STATUS,
    generateId: generateId,
    createSeedPhotoUrl: createSeedPhotoUrl,
    buildTenantRecord: buildTenantRecord,
    ensureSeedData: ensureSeedData,
    init: ensureSeedData,
    getTenants: getTenants,
    saveTenants: saveTenants,
    setFlash: setFlash,
    getFlash: getFlash,
    getAll: getAll,
    getById: getById,
    create: create,
    update: update,
    remove: remove
  };

}());
