(function () {
  'use strict';

  /* ===== SVG ICONS ===== */
  var ICONS = {
    home: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"/></svg>',
    building: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5 3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21"/></svg>',
    users: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z"/></svg>',
    documentText: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"/></svg>',
    plus: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15"/></svg>',
    pencil: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10"/></svg>',
    trash: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"/></svg>',
    checkCircle: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>',
    exclamationTriangle: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"/></svg>',
    informationCircle: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z"/></svg>',
    xCircle: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>',
    mapPin: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z"/></svg>',
    key: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 5.25a3 3 0 013 3m3 0a6 6 0 01-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1121.75 8.25z"/></svg>',
    calendar: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5"/></svg>',
    currencyDollar: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6v12m-3-2.818l.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>',
    arrowLeft: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18"/></svg>',
    xMark: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>',
    photo: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z"/></svg>',
    bed: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z"/></svg>',
    drop: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 3c-4.418 0-8 4.03-8 9a8 8 0 0016 0c0-4.97-3.582-9-8-9z"/></svg>',
    chartBar: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z"/></svg>',
    wrench: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M11.42 15.17L17.25 21A2.652 2.652 0 0021 17.25l-5.877-5.877M11.42 15.17l2.496-3.03c.317-.384.74-.626 1.208-.766M11.42 15.17l-4.655 5.653a2.548 2.548 0 11-3.586-3.586l6.837-5.63m5.108-.233c.55-.164 1.163-.188 1.743-.14a4.5 4.5 0 004.486-6.336l-3.276 3.277a3.004 3.004 0 01-2.25-2.25l3.276-3.276a4.5 4.5 0 00-6.336 4.486c.091 1.076-.071 2.264-.904 2.95l-.102.085m-1.745 1.437L5.909 7.5H4.5L2.25 3.75l1.5-1.5L7.5 4.5v1.409l4.26 4.26m-1.745 1.437l1.745-1.437m6.615 8.206L15.75 15.75M4.867 19.125h.008v.008h-.008v-.008z"/></svg>'
  };

  /* ===== HELPERS ===== */
  function getBasePath() {
    var path = window.location.pathname;
    return (path.indexOf('/pages/') !== -1 || path.indexOf('\\pages\\') !== -1) ? '../' : '';
  }

  function esc(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function formatPrice(price) {
    return '$' + Number(price).toLocaleString('es-MX');
  }

  function formatDate(dateStr) {
    if (!dateStr) return '—';
    var parts = dateStr.split('-');
    if (parts.length < 3) return dateStr;
    var months = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
    return parts[2] + ' ' + months[parseInt(parts[1], 10) - 1] + ' ' + parts[0];
  }

  /* ===== SIDEBAR / SHELL ===== */
  var NAV_ITEMS = [
    { key: 'dashboard',     label: 'Dashboard',         href: 'index.html',             icon: 'home' },
    { key: 'properties',    label: 'Mis propiedades',   href: 'pages/properties.html',  icon: 'building' },
    { key: 'tenants',       label: 'Inquilinos',        href: 'pages/tenants.html',     icon: 'users' },
    { key: 'add-property',  label: 'Nueva propiedad',   href: 'pages/add-property.html',icon: 'plus' },
    { key: 'rent-property', label: 'Registrar renta',   href: 'pages/rent-property.html',icon: 'key' }
  ];

  function mountShell(activeKey, pageTitle, pageSub, headerActions) {
    var base = getBasePath();
    var app = document.getElementById('app');
    if (!app) return;

    var navHtml = '';
    for (var i = 0; i < NAV_ITEMS.length; i++) {
      var item = NAV_ITEMS[i];
      var isActive = item.key === activeKey;
      var href = (item.key === 'dashboard') ? base + 'index.html' : base + item.href;
      navHtml += '<a class="nav-item' + (isActive ? ' nav-item--active' : '') + '" href="' + href + '">'
        + '<span class="nav-item__icon">' + ICONS[item.icon] + '</span>'
        + esc(item.label)
        + '</a>';
    }

    var actionsHtml = headerActions || '';

    app.innerHTML = '<div class="shell">'
      + '<aside class="sidebar" id="sidebar">'
        + '<div class="sidebar__brand">'
          + '<div class="sidebar__brand-icon">' + ICONS.building + '</div>'
          + '<div class="sidebar__brand-text">'
            + '<div class="sidebar__brand-name">Realtor</div>'
            + '<div class="sidebar__brand-sub">Gestión de rentas</div>'
          + '</div>'
        + '</div>'
        + '<nav class="sidebar__nav">'
          + '<div class="sidebar__section-title">Menú principal</div>'
          + navHtml
        + '</nav>'
      + '</aside>'
      + '<div class="main" id="main">'
        + '<div class="page-header" id="page-header">'
          + '<div class="page-header__left">'
            + '<div class="page-header__title">' + esc(pageTitle || '') + '</div>'
            + (pageSub ? '<div class="page-header__sub">' + esc(pageSub) + '</div>' : '')
          + '</div>'
          + (actionsHtml ? '<div class="page-header__actions">' + actionsHtml + '</div>' : '')
        + '</div>'
        + '<div class="page-content" id="page-content"></div>'
      + '</div>'
    + '</div>';

    return document.getElementById('page-content');
  }

  /* ===== FLASH ===== */
  function showFlash() {
    var flash = window.RealtorStorage.getFlash();
    if (!flash) return;
    var container = document.getElementById('flash-container');
    if (!container) return;
    var el = document.createElement('div');
    el.className = 'flash-msg flash-msg--' + (flash.type || 'success');
    el.textContent = flash.message;
    container.appendChild(el);
    setTimeout(function () {
      if (el.parentNode) el.parentNode.removeChild(el);
    }, 3200);
  }

  /* ===== CONFIRM MODAL ===== */
  function showConfirm(title, message, onConfirm, confirmLabel, confirmClass) {
    var overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = '<div class="modal">'
      + '<div class="modal__title">' + esc(title) + '</div>'
      + '<div class="modal__body">' + esc(message) + '</div>'
      + '<div class="modal__actions">'
        + '<button class="btn btn--secondary" id="modal-cancel">Cancelar</button>'
        + '<button class="btn ' + (confirmClass || 'btn--danger') + '" id="modal-confirm">' + esc(confirmLabel || 'Confirmar') + '</button>'
      + '</div>'
    + '</div>';
    document.body.appendChild(overlay);

    document.getElementById('modal-cancel').onclick = function () {
      document.body.removeChild(overlay);
    };
    document.getElementById('modal-confirm').onclick = function () {
      document.body.removeChild(overlay);
      onConfirm();
    };
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) document.body.removeChild(overlay);
    });
  }

  /* ===== BADGE ===== */
  function renderBadge(status) {
    var key = status ? status.replace(/\s+/g, '') : '';
    var cssMap = {
      'disponible':   'disponible',
      'rentada':      'rentada',
      'enmantenimiento': 'mantenimiento',
      'activo':       'activo',
      'pendiente':    'pendiente',
      'finalizado':   'finalizado'
    };
    var cls = cssMap[key] || 'finalizado';
    return '<span class="badge badge--' + cls + '">' + esc(status) + '</span>';
  }

  /* ===== ALERT ===== */
  function renderAlert(message, type) {
    var iconMap = {
      success: ICONS.checkCircle,
      danger:  ICONS.xCircle,
      warning: ICONS.exclamationTriangle,
      info:    ICONS.informationCircle
    };
    return '<div class="alert alert--' + (type || 'info') + '">'
      + (iconMap[type] || iconMap.info)
      + '<span>' + esc(message) + '</span>'
    + '</div>';
  }

  /* ===== METRIC CARD ===== */
  function renderMetricCard(value, label, iconKey, colorClass) {
    return '<div class="metric-card">'
      + '<div class="metric-card__icon metric-card__icon--' + (colorClass || 'primary') + '">' + (ICONS[iconKey] || ICONS.chartBar) + '</div>'
      + '<div class="metric-card__body">'
        + '<div class="metric-card__value">' + esc(String(value)) + '</div>'
        + '<div class="metric-card__label">' + esc(label) + '</div>'
      + '</div>'
    + '</div>';
  }

  /* ===== PROPERTY CARD ===== */
  function renderPropertyCard(property, actions) {
    var actionsHtml = actions || '';
    return '<div class="property-card">'
      + '<div class="property-card__img-wrap">'
        + '<img class="property-card__img" src="' + esc(property.image) + '" alt="' + esc(property.title) + '"'
          + ' onerror="this.classList.add(\'is-hidden\');this.nextElementSibling.classList.add(\'is-visible\')">'
        + '<div class="property-card__img-fallback">' + ICONS.photo + '<span>Sin imagen</span></div>'
      + '</div>'
      + '<div class="property-card__body">'
        + '<div class="property-card__title" title="' + esc(property.title) + '">' + esc(property.title) + '</div>'
        + '<div class="property-card__address">' + ICONS.mapPin + esc(property.address) + '</div>'
        + '<div class="property-card__desc">' + esc(property.description || '') + '</div>'
        + '<div class="property-card__meta">'
          + '<span class="property-card__meta-item">' + ICONS.bed + esc(property.bedrooms) + ' hab.</span>'
          + '<span class="property-card__meta-item">' + ICONS.drop + esc(property.bathrooms) + ' baños</span>'
        + '</div>'
      + '</div>'
      + '<div class="property-card__footer">'
        + '<div>'
          + '<div class="property-card__price">' + formatPrice(property.price) + ' <span>/mes</span></div>'
          + renderBadge(property.status)
        + '</div>'
        + '<div class="property-card__actions">' + actionsHtml + '</div>'
      + '</div>'
    + '</div>';
  }

  /* ===== QUICK ACTION ===== */
  function renderQuickAction(href, iconKey, label, sub) {
    return '<a class="quick-action" href="' + esc(href) + '">'
      + '<div class="quick-action__icon">' + ICONS[iconKey] + '</div>'
      + '<div>'
        + '<div class="quick-action__label">' + esc(label) + '</div>'
        + '<div class="quick-action__sub">' + esc(sub) + '</div>'
      + '</div>'
    + '</a>';
  }

  /* ===== EMPTY STATE ===== */
  function renderEmptyState(iconKey, title, text, actionHtml) {
    return '<div class="empty-state">'
      + '<div class="empty-state__icon">' + ICONS[iconKey] + '</div>'
      + '<div class="empty-state__title">' + esc(title) + '</div>'
      + '<div class="empty-state__text">' + esc(text) + '</div>'
      + (actionHtml || '')
    + '</div>';
  }

  /* ===== BACK LINK ===== */
  function renderBackLink(href, label) {
    return '<a class="back-link" href="' + esc(href) + '">' + ICONS.arrowLeft + esc(label || 'Volver') + '</a>';
  }

  function renderTenantRow(tenant, actions) {
    var notes = String(tenant.notes || '').trim();
    var notesText = notes ? notes : 'Sin notas';
    var notesTitle = notes ? notes : 'Sin notas';
    return '<tr>'
      + '<td><strong>' + esc(tenant.name) + '</strong></td>'
      + '<td>' + esc(tenant.email) + '</td>'
      + '<td>' + esc(tenant.phone) + '</td>'
      + '<td>' + esc(tenant.documentId) + '</td>'
      + '<td class="tenant-notes" title="' + esc(notesTitle) + '">' + esc(notesText) + '</td>'
      + '<td>' + (actions || '') + '</td>'
    + '</tr>';
  }

  window.RealtorUI = {
    ICONS: ICONS,
    getBasePath: getBasePath,
    esc: esc,
    formatPrice: formatPrice,
    formatDate: formatDate,
    mountShell: mountShell,
    showFlash: showFlash,
    showConfirm: showConfirm,
    renderBadge: renderBadge,
    renderAlert: renderAlert,
    renderMetricCard: renderMetricCard,
    renderPropertyCard: renderPropertyCard,
    renderQuickAction: renderQuickAction,
    renderEmptyState: renderEmptyState,
    renderBackLink: renderBackLink,
    renderTenantRow: renderTenantRow
  };

}());
