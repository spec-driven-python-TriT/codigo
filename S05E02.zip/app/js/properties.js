(function () {
  'use strict';

  var S = window.RealtorStorage;
  var KEY = S.KEYS.PROPERTIES;
  var VALID_STATUS = [
    S.PROPERTY_STATUS.AVAILABLE,
    S.PROPERTY_STATUS.RENTED,
    S.PROPERTY_STATUS.MAINTENANCE
  ];

  function getAll() {
    return S.getAll(KEY);
  }

  function getById(id) {
    return S.getById(KEY, id);
  }

  function validateProperty(data) {
    var payload = data || {};
    var errors = {};
    if (!payload.title || !String(payload.title).trim()) errors.title = 'El título es requerido';
    if (!payload.address || !String(payload.address).trim()) errors.address = 'La dirección es requerida';
    if (!payload.price || isNaN(payload.price) || Number(payload.price) <= 0) errors.price = 'El precio debe ser mayor a 0';
    if (!payload.description || !String(payload.description).trim()) errors.description = 'La descripción es requerida';
    if (!payload.status || VALID_STATUS.indexOf(payload.status) === -1) errors.status = 'Selecciona un estado válido';
    if (!payload.bedrooms || isNaN(payload.bedrooms) || Number(payload.bedrooms) < 1) errors.bedrooms = 'Mínimo 1 habitación';
    if (!payload.bathrooms || isNaN(payload.bathrooms) || Number(payload.bathrooms) < 1) errors.bathrooms = 'Mínimo 1 baño';

    if (payload.image && String(payload.image).trim()) {
      var image = String(payload.image).trim();
      if (!/^https?:\/\//i.test(image)) {
        errors.image = 'La imagen debe ser una URL válida (http/https)';
      }
    }

    return Object.keys(errors).length ? errors : null;
  }

  function createProperty(data) {
    var id = S.generateId();
    var now = new Date().toISOString();
    var image = data.image && String(data.image).trim() ? String(data.image).trim() : S.createSeedPhotoUrl(id);
    var property = {
      id: id,
      title: String(data.title).trim(),
      address: String(data.address).trim(),
      price: Number(data.price),
      description: String(data.description).trim(),
      status: data.status || S.PROPERTY_STATUS.AVAILABLE,
      bedrooms: Number(data.bedrooms),
      bathrooms: Number(data.bathrooms),
      image: image,
      createdAt: now,
      updatedAt: now
    };
    return S.create(KEY, property);
  }

  function updateProperty(id, data) {
    var current = getById(id);
    var image = data.image && String(data.image).trim()
      ? String(data.image).trim()
      : (current && current.image ? current.image : S.createSeedPhotoUrl(id));

    var updates = {
      title: String(data.title).trim(),
      address: String(data.address).trim(),
      price: Number(data.price),
      description: String(data.description).trim(),
      status: data.status,
      bedrooms: Number(data.bedrooms),
      bathrooms: Number(data.bathrooms),
      image: image,
      updatedAt: new Date().toISOString()
    };
    return S.update(KEY, id, updates);
  }

  function listProperties(filters) {
    var list = getAll();
    var criteria = filters || {};
    if (!criteria.status || criteria.status === 'all') return list;

    var out = [];
    for (var i = 0; i < list.length; i++) {
      if (list[i].status === criteria.status) out.push(list[i]);
    }
    return out;
  }

  function remove(id) {
    var rentals = S.getAll(S.KEYS.RENTALS);
    for (var i = 0; i < rentals.length; i++) {
      if (rentals[i].propertyId === id && rentals[i].contractStatus === S.CONTRACT_STATUS.ACTIVE) {
        S.update(S.KEYS.RENTALS, rentals[i].id, { contractStatus: S.CONTRACT_STATUS.ENDED });
      }
    }
    S.remove(KEY, id);
  }

  window.RealtorProperties = {
    listProperties: listProperties,
    createProperty: createProperty,
    updateProperty: updateProperty,
    getPropertyById: getById,
    validateProperty: validateProperty,

    // Compatibilidad con APIs existentes
    getAll: getAll,
    getById: getById,
    validate: validateProperty,
    create: createProperty,
    update: updateProperty,
    remove: remove
  };

}());
