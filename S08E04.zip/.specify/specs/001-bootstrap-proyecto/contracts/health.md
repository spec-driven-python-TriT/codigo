# Contrato — `GET /health`

## Propósito

Verificar disponibilidad de la aplicación FastAPI y de la base de datos
Supabase (mediante `SELECT 1` asíncrono).

## Endpoint

- **Método**: `GET`
- **Ruta**: `/health`
- **Autenticación**: ninguna.
- **Idempotencia**: sí.

## Parámetros

Ninguno.

## Respuestas

### 200 OK — base de datos disponible

```json
{
  "app": "ok",
  "db": "ok"
}
```

Headers: `Content-Type: application/json`.

### 503 Service Unavailable — base de datos no disponible

```json
{
  "app": "ok",
  "db": "down"
}
```

Headers: `Content-Type: application/json`.

Comportamientos asociados:

- Antes de devolver 503, se emite log estructurado nivel `WARNING` con
  `event="health.db_down"` y mensaje del error subyacente (sin filtrar
  credenciales ni la URL completa de la base).
- En el camino 200 OK NO se emite log (clarificación 7 del spec).

## Implementación de referencia

- Handler `async def health(...)` en `app/main.py`.
- Inyecta `AsyncSession` vía dependencia `get_session`.
- Ejecuta `await session.execute(text("SELECT 1"))` envuelto en `try/except`
  amplio (cualquier excepción → rama 503).
- Retorna instancia de `EstadoSalud` (Pydantic v2 frozen).

## Pruebas mínimas

- `tests/test_health.py::test_health_ok`: mockea sesión que retorna 1 → asserts
  status 200 y body `{"app": "ok", "db": "ok"}`.
- `tests/test_health.py::test_health_db_down`: mockea sesión que lanza
  excepción → asserts status 503 y body `{"app": "ok", "db": "down"}`.
