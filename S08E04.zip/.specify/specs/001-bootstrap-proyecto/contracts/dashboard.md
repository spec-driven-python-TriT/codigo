# Contrato — `GET /`

## Propósito

Renderizar el dashboard demo del sistema con la base visual fundacional:
sidebar, navbar y exactamente tres tarjetas métricas hardcoded.

## Endpoint

- **Método**: `GET`
- **Ruta**: `/`
- **Autenticación**: ninguna en esta spec.
- **Idempotencia**: sí.

## Respuesta

- **Status**: `200 OK`.
- **Content-Type**: `text/html; charset=utf-8`.
- **Cuerpo**: HTML completo renderizado por `app/templates/index.html` que
  extiende `app/templates/base.html`.

## Estructura HTML mínima exigida

El HTML devuelto DEBE contener (verificable por test):

1. Un elemento con clase `sidebar` (renderizado desde `_sidebar.html`).
2. Un elemento con clase `navbar` (renderizado desde `_navbar.html`) que
   incluye el botón toggle con icono `menu` (visible bajo 1024px) y `x`
   (estado abierto).
3. Una sección con clase `dashboard-metricas` que contiene exactamente
   **tres** elementos con clase `tarjeta-metrica` (renderizados desde
   `_tarjeta_metrica.html`).
4. Cada tarjeta métrica incluye su `etiqueta`, `valor` y un SVG inline
   resultado del macro `icon(nombre)` (sin `<img>` ni `<i>`).
5. Una zona con clase `flash` (vacía en esta spec) ubicada dentro de `<main>`.

## Comportamiento responsive

- Por encima de 1024px: sidebar visible permanentemente; toggle oculto.
- Entre 640px y 1024px: sidebar oculta por defecto, toggle visible; al activar
  toggle se aplica clase `sidebar--abierta` al `<aside>`.
- Bajo 640px: igual que el rango anterior, con padding reducido en `<main>`.

## Logging

- Camino feliz: sin logs.
- Excepción no controlada en el handler: log nivel `ERROR` con
  `event="dashboard.error"` antes de propagar la excepción al manejador global
  de FastAPI.

## Pruebas mínimas

- `tests/test_dashboard.py::test_dashboard_renderiza_estructura`: status 200 y
  HTML contiene los selectores `class="sidebar"`, `class="navbar"`,
  `class="dashboard-metricas"` y exactamente tres ocurrencias de
  `class="tarjeta-metrica"`.
- `tests/test_dashboard.py::test_dashboard_iconos_inline`: el HTML contiene al
  menos tres elementos `<svg` (uno por tarjeta) y NO contiene tags
  `<i class=` ni referencias a webfonts de iconos.
