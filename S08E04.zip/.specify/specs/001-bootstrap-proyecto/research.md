# Investigación — 001 Bootstrap del Proyecto Realtor

Resoluciones técnicas para la fase de planificación. Todas las decisiones se
toman dentro de los límites del stack obligatorio (constitution v1.1.0).

## 1. Engine async para Supabase transaction pooler

- **Decisión**: Crear `AsyncEngine` con `create_async_engine(DATABASE_URL,
  connect_args={"statement_cache_size": 0, "prepared_statement_cache_size": 0,
  "ssl": "require"}, pool_pre_ping=True)`.
- **Rationale**: El transaction pooler de Supabase (puerto 6543, modo
  transaction) NO soporta prepared statements persistentes; asyncpg debe
  desactivar tanto el cache de statements como el cache de prepared statements.
  SSL `require` es obligatorio según política de Supabase.
- **Alternativas consideradas**:
  - Usar el session pooler (puerto 5432 vía PgBouncer session-mode): rechazado
    por menor escalabilidad para FastAPI.
  - Usar conexión directa para runtime: rechazado por límite estricto de
    conexiones simultáneas en Supabase.

## 2. Alembic en modo async con conexión directa

- **Decisión**: `alembic/env.py` configurado en modo async usando
  `async_engine_from_config` y leyendo `DATABASE_URL_DIRECT` desde
  `app.config.Settings`. `alembic.ini` no contiene URL hardcoded (`sqlalchemy.url
  =`).
- **Rationale**: El transaction pooler no soporta operaciones DDL ni advisory
  locks que Alembic puede emitir; la conexión directa (puerto 5432) sí. La
  separación garantiza que migraciones nunca compartan ruta con runtime.
- **Alternativas**: usar Alembic sync sobre el directo: rechazado porque rompe
  Principio VII (Async-First) y exige driver psycopg2 adicional.

## 3. Rangos de versión `~=` para dependencias

- **Decisión**: Declarar producción y desarrollo con `~=MAYOR.MINOR` para fijar
  major+minor y permitir patches: `fastapi ~=0.115`, `uvicorn[standard] ~=0.32`,
  `sqlalchemy ~=2.0`, `asyncpg ~=0.30`, `alembic ~=1.14`, `pydantic ~=2.9`,
  `pydantic-settings ~=2.6`, `jinja2 ~=3.1`, `python-multipart ~=0.0.12`,
  `pytest ~=8.3`, `pytest-asyncio ~=0.24`, `httpx ~=0.27`, `ruff ~=0.7`,
  `mypy ~=1.13`. `uv.lock` fija exactamente las versiones resueltas.
- **Rationale**: Compromiso entre estabilidad y recepción de bugfixes; alineado
  con prácticas habituales del ecosistema FastAPI/SQLAlchemy.
- **Alternativas**: rangos `>=` libres (rechazado, riesgo de roturas) o
  versiones exactas (rechazado, no permite patches de seguridad sin tocar
  `pyproject.toml`).

## 4. Breakpoints responsive y comportamiento de sidebar

- **Decisión** (clarificación 1 del spec): dos breakpoints en `app.css` —
  `--breakpoint-md: 1024px` (escritorio/tablet horizontal) y
  `--breakpoint-sm: 640px` (móvil). Sidebar fija a la izquierda en escritorio;
  bajo 1024px se transforma en panel colapsable controlado por toggle en
  `_navbar.html` (atributo `data-open` + clase `sidebar--abierta`).
- **Rationale**: 1024px y 640px son breakpoints estándar adoptados ampliamente
  por sistemas de diseño (Material, Tailwind defaults). Permite degradación
  progresiva sin JavaScript de terceros: el toggle se implementa con un script
  vanilla mínimo en `base.html`.
- **Alternativas**: tres breakpoints (rechazado por sobreingeniería para spec
  fundacional); CSS-only con `:checked` hack (rechazado por menor accesibilidad
  ARIA).

## 5. Vendoreo de HTMX

- **Decisión**: Descargar `htmx.min.js` (versión 2.x) desde el repositorio
  oficial (https://github.com/bigskysoftware/htmx) y guardarlo en
  `app/static/vendor/htmx.min.js`. Referenciarlo en `base.html` con
  `<script src="{{ url_for('static', path='vendor/htmx.min.js') }}" defer></script>`.
- **Rationale**: Constitution Principio IV prohíbe CDN en runtime. La carga
  `defer` evita bloquear el render del layout base.
- **Alternativas**: importar como dependencia npm (rechazado, viola "único
  proyecto Python" sin bundler).

## 6. Iconografía Lucide

- **Decisión** (clarificación 5 del spec): Generar inline cada SVG outline desde
  el repositorio oficial Lucide (https://lucide.dev). Cada archivo
  `app/static/icons/<nombre>.svg` contiene exactamente el `<svg>` outline,
  width/height 24, stroke-width 2, sin atributos `class` predefinidos.
- **Rationale**: Permite que el macro `icon(nombre, size, class)` sustituya
  `width`, `height` y `class` en el momento de render Jinja2 sin colisiones.
- **Alternativas**: sprite SVG único (rechazado por no cumplir "uno por
  archivo" del principio IV); webfont (prohibido por constitution).

## 7. Logging condicional en `/health` y `/`

- **Decisión** (clarificación 7 del spec): No emitir logs en el camino feliz.
  Emitir log estructurado **solo** cuando ocurre un error (DB caída en
  `/health` → log `WARNING`; excepción no controlada en `/` → log `ERROR`).
  Configurar logging básico en `app/main.py` con nivel desde
  `Settings.LOG_LEVEL` y formato `%(asctime)s %(levelname)s %(name)s %(message)s`.
- **Rationale**: Reduce ruido en producción y respeta Principio V (logging
  estructurado sin datos sensibles).

## 8. Migración baseline con `pgcrypto`

- **Decisión** (clarificación 6 del spec): La migración `0001_baseline.py`
  ejecuta `CREATE EXTENSION IF NOT EXISTS pgcrypto;` y deja explícitamente
  documentado en docstring que `gen_random_uuid()` queda disponible. No crea
  tablas de dominio en esta spec.
- **Rationale**: Habilita `gen_random_uuid()` como default server-side de UUIDs
  para entidades futuras (spec 002+). Mantener una migración baseline asegura
  que `alembic upgrade head` sea verificable desde la primera spec.

## 9. CSS propio con tokens en `:root`

- **Decisión**: `app/static/css/app.css` contiene en `:root` tokens de color
  (`--color-bg`, `--color-superficie`, `--color-borde`, `--color-texto`,
  `--color-acento`, `--color-exito`, `--color-aviso`, `--color-error`,
  `--color-info`), espaciado (`--espacio-1` a `--espacio-8`), tipografía
  (`--fuente-base`, `--peso-regular`, `--peso-bold`), radios (`--radio-sm`,
  `--radio-md`) y breakpoints. El archivo se organiza con siete secciones
  comentadas en este orden: `/* 1. RESET */`, `/* 2. VARIABLES */`,
  `/* 3. TIPOGRAFÍA */`, `/* 4. LAYOUT */`, `/* 5. COMPONENTES */`,
  `/* 6. UTILIDADES */`, `/* 7. RESPONSIVE */`.
- **Rationale**: Estructura predecible y autodocumentada; facilita extensión
  en specs futuras sin necesidad de framework CSS.

## 10. Estructura mínima de tests

- **Decisión**: `tests/test_health.py` y `tests/test_dashboard.py` con
  `httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test")`.
  Configurar `pytest-asyncio` con `asyncio_mode = "auto"` en `pyproject.toml`
  para evitar decoradores explícitos. Los tests NO requieren conexión real a
  Supabase: el test de `/health` mockea la sesión async para ejercer ambas
  ramas (200 ok / 503 down).
- **Rationale**: Permite validar el contrato HTTP sin red externa y mantiene
  CI rápido y reproducible.
- **Alternativas**: usar testcontainers Postgres (rechazado en esta spec por
  alcance; se reevaluará en spec 002).
