# Modelo de Datos — 001 Bootstrap del Proyecto Realtor

Esta spec NO introduce entidades de dominio persistidas. Modela únicamente
estructuras de configuración, contratos de respuesta y la migración baseline.

## 1. `Settings` (configuración tipada)

Origen: `app/config.py` usando `pydantic-settings` v2.

| Campo | Tipo | Origen | Validación |
|-------|------|--------|------------|
| `DATABASE_URL` | `str` | env / `.env` | Obligatorio, no vacío. Esquema esperado: `postgresql+asyncpg://...:6543/...`. |
| `DATABASE_URL_DIRECT` | `str` | env / `.env` | Obligatorio, no vacío. Esquema esperado: `postgresql+asyncpg://...:5432/...`. |
| `APP_ENV` | `Literal["dev", "test", "prod"]` | env / `.env` | Default `"dev"`. |
| `LOG_LEVEL` | `Literal["DEBUG", "INFO", "WARNING", "ERROR"]` | env / `.env` | Default `"INFO"`. |

Reglas:

- `model_config = SettingsConfigDict(env_file=".env", frozen=True, extra="ignore")`.
- Si falta `DATABASE_URL` o `DATABASE_URL_DIRECT`, Pydantic eleva
  `ValidationError` y la app NO arranca (caso límite del spec).
- Se expone una factory cacheada `get_settings()` con `functools.lru_cache`
  para reuso en dependencias FastAPI.

## 2. `EstadoSalud` (respuesta de `GET /health`)

Origen: definido inline en `app/main.py` como `BaseModel` Pydantic v2 con
`model_config = ConfigDict(frozen=True)`.

| Campo | Tipo | Valores posibles |
|-------|------|------------------|
| `app` | `Literal["ok"]` | Siempre `"ok"` si el handler ejecuta. |
| `db` | `Literal["ok", "down"]` | `"ok"` si `SELECT 1` async retorna; `"down"` si la conexión o el query fallan. |

Códigos HTTP:

- `200 OK` cuando `db == "ok"`.
- `503 Service Unavailable` cuando `db == "down"` (clarificación 2 del spec).

## 3. `MetricaDashboard` (estructura para tarjetas)

Origen: definido en `app/main.py` (o `app/templates/index.html` directamente)
como `BaseModel` Pydantic v2 con `frozen=True`. Datos hardcoded para esta spec.

| Campo | Tipo | Ejemplo |
|-------|------|---------|
| `etiqueta` | `str` | `"Usuarios activos"` |
| `valor` | `str` | `"1.248"` |
| `icono` | `str` | `"users"` (nombre de archivo SVG sin extensión) |

Las tres tarjetas (clarificación 3 del spec):

1. `etiqueta="Usuarios activos"`, `icono="users"`.
2. `etiqueta="Propiedades listadas"`, `icono="building-2"`.
3. `etiqueta="Visitas hoy"`, `icono="layout-dashboard"`.

> Nota: el spec menciona iconos `user/home/eye`; se mapean a la lista
> obligatoria de 13 iconos Lucide así: `user → users`, `home → building-2`
> (más representativo de propiedades inmobiliarias), `eye → layout-dashboard`
> (representativo de actividad del día). Esta sustitución se documenta aquí y
> se reflejará en `tasks.md`.

## 4. Migración baseline (`alembic/versions/0001_baseline.py`)

- `revision = "0001"`, `down_revision = None`.
- `upgrade()`: ejecuta `op.execute("CREATE EXTENSION IF NOT EXISTS pgcrypto;")`.
- `downgrade()`: ejecuta `op.execute("DROP EXTENSION IF EXISTS pgcrypto;")`.
- Docstring en español indica que esta migración habilita `gen_random_uuid()`
  para uso server-side por entidades futuras.

No se crean tablas en esta spec.

## 5. Estado y transiciones

No aplica: no hay máquinas de estado en esta spec. Solo se modela la
disponibilidad binaria de la base de datos en `EstadoSalud.db`.
