# Quickstart — 001 Bootstrap del Proyecto Realtor

Guía mínima para arrancar y verificar el esqueleto técnico tras la
implementación de esta spec.

## 1. Requisitos previos

- Python 3.13+ instalado.
- `uv` instalado (https://docs.astral.sh/uv/).
- Acceso a un proyecto Supabase con dos URLs disponibles:
  - Transaction pooler (puerto 6543) → `DATABASE_URL`.
  - Conexión directa (puerto 5432) → `DATABASE_URL_DIRECT`.

## 2. Configuración del entorno

Copiar la plantilla y completar los valores:

```bash
cp .env.example .env
```

Variables requeridas en `.env`:

```dotenv
DATABASE_URL=postgresql+asyncpg://USER:PASSWORD@HOST:6543/postgres
DATABASE_URL_DIRECT=postgresql+asyncpg://USER:PASSWORD@HOST:5432/postgres
APP_ENV=dev
LOG_LEVEL=INFO
```

## 3. Sincronizar dependencias

```bash
uv sync
```

Resultado esperado: descarga e instalación sin errores; se genera o actualiza
`uv.lock` (CE-001).

## 4. Aplicar migración baseline

```bash
uv run alembic upgrade head
```

Resultado esperado: la migración `0001_baseline` se aplica sin errores y
habilita la extensión `pgcrypto` en la base destino (CE-007). Alembic usa
`DATABASE_URL_DIRECT` automáticamente desde `alembic/env.py`.

## 5. Arrancar el servidor

```bash
uv run uvicorn app.main:app --reload
```

Resultado esperado: el servidor inicia en `http://127.0.0.1:8000` sin fallos
de importación ni configuración (CE-002).

## 6. Verificar `/health`

```bash
curl -i http://127.0.0.1:8000/health
```

Resultado esperado:

```http
HTTP/1.1 200 OK
content-type: application/json

{"app":"ok","db":"ok"}
```

(CE-003). Si la base no está disponible, el endpoint responde `503` con
`{"app":"ok","db":"down"}`.

## 7. Verificar `/`

Abrir `http://127.0.0.1:8000/` en el navegador. Resultado esperado (CE-004,
CE-005, CE-006):

- Sidebar visible a la izquierda.
- Navbar superior con toggle (visible bajo 1024px).
- Tres tarjetas métricas: "Usuarios activos", "Propiedades listadas" y
  "Visitas hoy", cada una con su SVG inline.
- Reduciendo el ancho a menos de 1024px la sidebar se colapsa y el toggle
  permite reabrirla.

## 8. Calidad estática

```bash
uv run ruff check .
uv run ruff format --check .
uv run mypy --strict app/modules/
uv run pytest
```

Resultados esperados (CE-008, CE-009): los tres primeros comandos finalizan
sin hallazgos; los tests de `tests/` pasan en verde.

## 9. Verificación documental

```bash
# No debe existir contenido en inglés en archivos .md del repo
uv run python -c "print('verificación manual: revisar README.md y .specify/**/*.md')"
```

(CE-010). Esta verificación se realiza manualmente durante la revisión de la
spec.
