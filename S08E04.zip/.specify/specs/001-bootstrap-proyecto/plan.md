# Plan de Implementación: Bootstrap del Proyecto Realtor

**Rama**: `001-bootstrap-proyecto` | **Fecha**: 2026-05-13 | **Spec**: [spec.md](spec.md)
**Entrada**: Especificación de feature en `.specify/specs/001-bootstrap-proyecto/spec.md`

## Resumen

Construir el esqueleto técnico y visual del sistema Realtor: aplicación FastAPI
async con configuración tipada (`pydantic-settings`), conexión a Supabase
Postgres usando dos URLs (transaction pooler para runtime, conexión directa
para Alembic), endpoint `/health` con `SELECT 1` async, dashboard demo en `/`
con sidebar/navbar y tres tarjetas métricas hardcoded, sistema de iconos SVG
local (13 iconos Lucide), CSS 100% propio con tokens de diseño, HTMX
vendoreado y configuración de calidad estática (Ruff + mypy --strict +
pytest-asyncio en modo `auto`). Esta spec NO introduce dominio de negocio: deja
todo lo necesario para que la spec 002 arranque sobre una base ejecutable y
verificable.

## Contexto Técnico

**Lenguaje/Versión**: Python 3.13+
**Dependencias principales**: FastAPI ~=0.115, Uvicorn[standard] ~=0.32,
SQLAlchemy ~=2.0 (async), asyncpg ~=0.30, Alembic ~=1.14, Pydantic ~=2.9,
pydantic-settings ~=2.6, Jinja2 ~=3.1, python-multipart ~=0.0.12
**Dependencias de desarrollo**: pytest ~=8.3, pytest-asyncio ~=0.24,
httpx ~=0.27, ruff ~=0.7, mypy ~=1.13
**Almacenamiento**: PostgreSQL gestionado por Supabase (asyncpg)
**Tests**: pytest + pytest-asyncio (`asyncio_mode = "auto"`) + httpx.AsyncClient
**Plataforma objetivo**: Servidor Linux (runtime) y Windows/macOS/Linux (dev)
**Tipo de proyecto**: Monolito modular web (FastAPI + Jinja2 + HTMX) — único
proyecto Python, sin separación frontend/backend
**Objetivos de rendimiento**: No aplica métrica numérica para esta spec; el
arranque debe completarse en <2s y `/health` debe responder en <300ms p95 con
DB disponible
**Restricciones**: SSL obligatorio contra Supabase
(`ssl=require`); engine de runtime debe usar
`statement_cache_size=0` + `prepared_statement_cache_size=0` por compatibilidad
con el transaction pooler; Alembic SOLO usa la conexión directa
(`DATABASE_URL_DIRECT`); HTMX debe servirse desde
`app/static/vendor/htmx.min.js` (sin CDN en runtime); CSS 100% propio
**Escala/Alcance**: Esqueleto inicial con 1 endpoint operativo (`/health`), 1
vista demo (`/`), layout base, 8 componentes estructurales, 13 iconos, 1
migración baseline con `pgcrypto`

## Verificación de Constitution

*GATE: Debe pasar antes de Fase 0. Re-evaluar después de Fase 1.*

| Principio | Estado | Justificación |
|-----------|--------|---------------|
| I. Solución Única y Compartida | PASA | Un solo proyecto Python; sin separación frontend/backend; `app/main.py` monta todo. |
| II. Spec-Driven Development | PASA | Toda tarea rastreará a `tasks.md` de esta spec; no se introduce funcionalidad fuera del alcance descrito. |
| III. Vertical Slice Architecture | PASA | Esta spec NO introduce módulos de dominio. Las vistas `/` y `/health` viven en `app/main.py` (bootstrap), sin crear carpetas globales por capa. La estructura `app/modules/` queda preparada vacía para spec 002. |
| IV. Stack Tecnológico Obligatorio | PASA | uv + FastAPI + SQLAlchemy 2.x async + Pydantic v2 + Alembic + asyncpg + pytest-asyncio + Ruff + mypy --strict + CSS propio + HTMX vendoreado + 13 iconos Lucide outline locales. |
| V. Calidad de Dominio y Contratos | PASA (parcial) | No hay lógica de dominio en esta spec. `/health` retorna un schema Pydantic (`EstadoSalud`); errores se modelan con HTTP 503 + payload tipado. Logging estructurado solo en error según clarificación 7. |
| VI. Idioma y Documentación | PASA | Toda la documentación (`spec.md`, `plan.md`, futuro `tasks.md`, `research.md`, `data-model.md`, `quickstart.md`) en español. Docstrings en español. |
| VII. Async-First | PASA | `AsyncEngine`, `AsyncSession`, `async def` en endpoints, `httpx.AsyncClient` en tests, Alembic en modo async. |

**Resultado**: Sin violaciones. No se requiere Complexity Tracking.

## Estructura del Proyecto

### Documentación (de esta feature)

```text
.specify/specs/001-bootstrap-proyecto/
├── plan.md              # Este archivo
├── spec.md              # Especificación aprobada
├── research.md          # Decisiones técnicas resueltas (Fase 0)
├── data-model.md        # Entidades de configuración y contratos de respuesta
├── quickstart.md        # Guía de arranque y verificación
├── contracts/
│   ├── health.md        # Contrato del endpoint GET /health
│   └── dashboard.md     # Contrato de la vista GET /
└── tasks.md             # (generado por /speckit.tasks)
```

### Código fuente (raíz del repositorio)

```text
app/
  __init__.py
  main.py                          # FastAPI app, montaje de routers, /health, /
  config.py                        # Settings (pydantic-settings)
  database.py                      # AsyncEngine + AsyncSession + get_session
  modules/
    __init__.py                    # Vacío; reservado para spec 002
  static/
    css/
      app.css                      # CSS propio con :root tokens y 7 secciones comentadas
    vendor/
      htmx.min.js                  # HTMX vendoreado (sin CDN)
    icons/                         # 13 SVG outline Lucide (uno por archivo)
      layout-dashboard.svg
      building-2.svg
      users.svg
      file-text.svg
      wallet.svg
      wrench.svg
      settings.svg
      menu.svg
      x.svg
      check-circle-2.svg
      alert-triangle.svg
      alert-circle.svg
      info.svg
  templates/
    base.html                      # Layout: sidebar + main + zona flash
    index.html                     # Dashboard demo (extiende base)
    components/
      _sidebar.html
      _navbar.html
      _card_propiedad.html
      _tarjeta_metrica.html
      _accesos_rapidos.html
      _badge_estado.html
      _form_field.html
      _alerta.html
    macros/
      icons.html                   # macro icon(nombre, size, class)
alembic/
  env.py                           # async; lee DATABASE_URL_DIRECT
  script.py.mako
  versions/
    0001_baseline.py               # CREATE EXTENSION pgcrypto + gen_random_uuid()
alembic.ini
pyproject.toml                     # Gestionado por uv
uv.lock
.env.example                       # Plantilla para DATABASE_URL, DATABASE_URL_DIRECT, APP_ENV, LOG_LEVEL
tests/
  __init__.py
  test_health.py                   # httpx.AsyncClient → GET /health
  test_dashboard.py                # httpx.AsyncClient → GET / (estructura HTML)
```

**Decisión de estructura**: Monolito modular según constitución (Principio I y
III). En esta spec NO se crea ningún módulo bajo `app/modules/` porque la spec
es puramente fundacional; `app/modules/__init__.py` queda vacío como ancla
para spec 002. Las vistas `/health` y `/` son consideradas **infraestructura
de bootstrap** y viven en `app/main.py` para no crear un módulo artificial sin
dominio.

## Fase 0 — Investigación

Ver [research.md](research.md). Resuelve:

- Configuración del `AsyncEngine` para Supabase transaction pooler (cache de
  prepared statements desactivado, SSL `require`).
- Configuración de Alembic en modo async usando `DATABASE_URL_DIRECT`.
- Estrategia de rangos de versión `~=` para dependencias.
- Estrategia de breakpoints CSS (1024px, 640px) y comportamiento sidebar.
- Vendoreo de HTMX y de iconos Lucide.
- Modo de logging condicional (solo en error) en `/health` y `/`.

## Fase 1 — Diseño y Contratos

Ver:

- [data-model.md](data-model.md): entidades de configuración (`Settings`),
  payload de salud (`EstadoSalud`), estructura de tarjeta métrica
  (`MetricaDashboard`), y migración baseline.
- [contracts/health.md](contracts/health.md): contrato HTTP de `GET /health`.
- [contracts/dashboard.md](contracts/dashboard.md): contrato de la vista
  `GET /` (estructura HTML mínima esperada).
- [quickstart.md](quickstart.md): pasos para clonar, configurar `.env`,
  sincronizar dependencias con `uv sync`, aplicar migración baseline, arrancar
  el servidor y verificar `/health` y `/`.

**Verificación post-diseño de Constitution**: Sin nuevas violaciones. La
estructura propuesta respeta los siete principios.

## Complexity Tracking

> No aplica: la verificación de Constitution no reporta violaciones.
