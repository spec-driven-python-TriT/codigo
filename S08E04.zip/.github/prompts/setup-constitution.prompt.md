---
name: setup-constitution
description: Este prompt creara o modificara el constitution.md del proyecto
---
/speckit.constitution

Crea la constitution inicial del proyecto Realtor en v1.0.El proyecto es un monolito Python con FastAPI +
Jinja2 + HTMX + SQLAlchemy async + PostgreSQL (Supabase) gestionado con uv, en español, spec-driven, vertical slice architecture.

Idioma: todo el contenido en español.
