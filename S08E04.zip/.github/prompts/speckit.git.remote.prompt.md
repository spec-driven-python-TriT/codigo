---
agent: speckit.git.remote
---
