---
agent: speckit.git.initialize
---
