(function () {
  'use strict';

  var S = window.RealtorStorage;
  var KEY = S.KEYS.PROPERTIES;

  function getAll() {
    return S.getAll(KEY);
  }

  function getById(id) {
    return S.getById(KEY, id);
  }

  function validate(data) {
    var errors = {};
    if (!data.title || !String(data.title).trim()) errors.title = 'El título es requerido';
    if (!data.address || !String(data.address).trim()) errors.address = 'La dirección es requerida';
    if (!data.price || isNaN(data.price) || Number(data.price) <= 0) errors.price = 'El precio debe ser mayor a 0';
    if (!data.bedrooms || isNaN(data.bedrooms) || Number(data.bedrooms) < 1) errors.bedrooms = 'Mínimo 1 habitación';
    if (!data.bathrooms || isNaN(data.bathrooms) || Number(data.bathrooms) < 1) errors.bathrooms = 'Mínimo 1 baño';
    return Object.keys(errors).length ? errors : null;
  }

  function create(data) {
    var id = S.generateId();
    var now = new Date().toISOString();
    var property = {
      id: id,
      title: String(data.title).trim(),
      address: String(data.address).trim(),
      price: Number(data.price),
      description: String(data.description || '').trim(),
      status: data.status || S.PROPERTY_STATUS.AVAILABLE,
      bedrooms: Number(data.bedrooms),
      bathrooms: Number(data.bathrooms),
      image: S.createSeedPhotoUrl(id),
      createdAt: now,
      updatedAt: now
    };
    return S.create(KEY, property);
  }

  function update(id, data) {
    var updates = {
      title: String(data.title).trim(),
      address: String(data.address).trim(),
      price: Number(data.price),
      description: String(data.description || '').trim(),
      status: data.status,
      bedrooms: Number(data.bedrooms),
      bathrooms: Number(data.bathrooms),
      updatedAt: new Date().toISOString()
    };
    return S.update(KEY, id, updates);
  }

  function remove(id) {
    var rentals = S.getAll(S.KEYS.RENTALS);
    for (var i = 0; i < rentals.length; i++) {
      if (rentals[i].propertyId === id && rentals[i].contractStatus === S.CONTRACT_STATUS.ACTIVE) {
        S.update(S.KEYS.RENTALS, rentals[i].id, { contractStatus: S.CONTRACT_STATUS.ENDED });
      }
    }
    S.remove(KEY, id);
  }

  window.RealtorProperties = {
    getAll: getAll,
    getById: getById,
    validate: validate,
    create: create,
    update: update,
    remove: remove
  };

}());
