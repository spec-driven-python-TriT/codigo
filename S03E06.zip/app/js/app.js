(function () {
  'use strict';

  var S   = window.RealtorStorage;
  var UI  = window.RealtorUI;
  var P   = window.RealtorProperties;
  var T   = window.RealtorTenants;
  var R   = window.RealtorRentals;

  /* ===== ROUTING ===== */
  function getCurrentPage() {
    var path = window.location.pathname;
    // Normalize: replace backslashes, get last segment
    var normalized = path.replace(/\\/g, '/');
    var parts = normalized.split('/');
    var file = parts[parts.length - 1] || '';
    // Strip query string if any bled into filename
    return file.split('?')[0] || 'index.html';
  }

  var ROUTES = {
    'index.html':          initDashboard,
    '':                    initDashboard,
    'properties.html':     initProperties,
    'add-property.html':   initAddProperty,
    'edit-property.html':  initEditProperty,
    'rent-property.html':  initRentProperty,
    'tenants.html':        initTenants,
    'add-tenant.html':     initAddTenant,
    'edit-tenant.html':    initEditTenant
  };

  /* ===== QUERY STRING ===== */
  function getParam(name) {
    var search = window.location.search;
    var pairs = search.replace(/^\?/, '').split('&');
    for (var i = 0; i < pairs.length; i++) {
      var kv = pairs[i].split('=');
      if (decodeURIComponent(kv[0]) === name) return decodeURIComponent(kv[1] || '');
    }
    return null;
  }

  /* ===== FORM HELPERS ===== */
  function getFormData(form) {
    var data = {};
    var elements = form.elements;
    for (var i = 0; i < elements.length; i++) {
      var el = elements[i];
      if (el.name) data[el.name] = el.value;
    }
    return data;
  }

  function showFormErrors(form, errors) {
    // Clear previous
    var inputs = form.querySelectorAll('.form-input, .form-select, .form-textarea');
    for (var i = 0; i < inputs.length; i++) {
      inputs[i].classList.remove('is-error');
    }
    var errorEls = form.querySelectorAll('.form-error');
    for (var j = 0; j < errorEls.length; j++) {
      errorEls[j].textContent = '';
      errorEls[j].classList.remove('is-visible');
    }
    // Set new errors
    for (var field in errors) {
      if (!Object.prototype.hasOwnProperty.call(errors, field)) continue;
      var input = form.querySelector('[name="' + field + '"]');
      if (input) input.classList.add('is-error');
      var errorEl = form.querySelector('[data-error="' + field + '"]');
      if (errorEl) {
        errorEl.textContent = errors[field];
        errorEl.classList.add('is-visible');
      }
    }
  }

  function clearFormErrors(form) {
    var inputs = form.querySelectorAll('.form-input, .form-select, .form-textarea');
    for (var i = 0; i < inputs.length; i++) inputs[i].classList.remove('is-error');
    var errorEls = form.querySelectorAll('.form-error');
    for (var j = 0; j < errorEls.length; j++) {
      errorEls[j].textContent = '';
      errorEls[j].classList.remove('is-visible');
    }
  }

  /* ======================================================
     DASHBOARD
  ====================================================== */
  function initDashboard() {
    var base = UI.getBasePath();
    var content = UI.mountShell('dashboard', 'Dashboard', 'Bienvenido a tu gestor de rentas');
    UI.showFlash();

    var props    = P.getAll();
    var tenants  = T.getAll();
    var rentals  = R.getAll();
    var available    = 0;
    var rented       = 0;
    var maintenance  = 0;
    var activeContracts = 0;

    for (var i = 0; i < props.length; i++) {
      if (props[i].status === S.PROPERTY_STATUS.AVAILABLE)   available++;
      if (props[i].status === S.PROPERTY_STATUS.RENTED)      rented++;
      if (props[i].status === S.PROPERTY_STATUS.MAINTENANCE) maintenance++;
    }
    for (var j = 0; j < rentals.length; j++) {
      if (rentals[j].contractStatus === S.CONTRACT_STATUS.ACTIVE) activeContracts++;
    }

    var metricsHtml = '<div class="metrics-grid">'
      + UI.renderMetricCard(props.length,       'Total propiedades',    'building',       'primary')
      + UI.renderMetricCard(available,           'Disponibles',          'checkCircle',    'success')
      + UI.renderMetricCard(rented,              'Rentadas',             'key',            'muted')
      + UI.renderMetricCard(maintenance,         'En mantenimiento',     'wrench',         'warning')
      + UI.renderMetricCard(tenants.length,      'Inquilinos',           'users',          'primary')
      + UI.renderMetricCard(activeContracts,     'Contratos activos',    'documentText',   'success')
    + '</div>';

    var qaHtml = '<div class="quick-actions">'
      + UI.renderQuickAction(base + 'pages/properties.html',   'building',      'Mis propiedades', 'Ver todas')
      + UI.renderQuickAction(base + 'pages/add-property.html', 'plus',          'Nueva propiedad', 'Registrar')
      + UI.renderQuickAction(base + 'pages/rent-property.html','key',           'Registrar renta', 'Nuevo contrato')
      + UI.renderQuickAction(base + 'pages/tenants.html',      'users',         'Inquilinos',      'Ver todos')
    + '</div>';

    // Recent properties (last 6)
    var recentProps = props.slice(-6).reverse();
    var cardsHtml = '';
    for (var k = 0; k < recentProps.length; k++) {
      var prop = recentProps[k];
      var editHref = base + 'pages/edit-property.html?id=' + prop.id;
      var actions = '<a class="btn btn--icon" href="' + UI.esc(editHref) + '" title="Editar">' + UI.ICONS.pencil + '</a>';
      cardsHtml += UI.renderPropertyCard(prop, actions);
    }

    var recentSection = '<div class="section-header">'
      + '<div><div class="section-header__title">Propiedades recientes</div>'
      + '<div class="section-header__sub">Últimas ' + recentProps.length + ' propiedades registradas</div></div>'
      + '<a class="btn btn--secondary btn--sm" href="' + base + 'pages/properties.html">' + UI.ICONS.building + 'Ver todas</a>'
    + '</div>'
    + (recentProps.length ? '<div class="cards-grid">' + cardsHtml + '</div>'
        : UI.renderEmptyState('building', 'Sin propiedades', 'Aún no hay propiedades registradas.',
            '<a class="btn btn--primary" href="' + base + 'pages/add-property.html">' + UI.ICONS.plus + 'Nueva propiedad</a>'));

    content.innerHTML = metricsHtml + qaHtml + recentSection;
  }

  /* ======================================================
     PROPERTIES LIST
  ====================================================== */
  function initProperties() {
    var base = UI.getBasePath();
    var addBtn = '<a class="btn btn--primary" href="' + base + 'pages/add-property.html">' + UI.ICONS.plus + 'Nueva propiedad</a>';
    var content = UI.mountShell('properties', 'Mis propiedades', 'Gestiona tu portafolio', addBtn);
    UI.showFlash();

    var props = P.getAll();

    if (!props.length) {
      content.innerHTML = UI.renderEmptyState('building', 'Sin propiedades', 'Aún no hay propiedades registradas.',
        '<a class="btn btn--primary" href="' + base + 'pages/add-property.html">' + UI.ICONS.plus + 'Nueva propiedad</a>');
      return;
    }

    var cardsHtml = '';
    for (var i = 0; i < props.length; i++) {
      var prop = props[i];
      var editHref   = base + 'pages/edit-property.html?id=' + prop.id;
      var deleteId   = prop.id;
      var actions = '<a class="btn btn--icon" href="' + UI.esc(editHref) + '" title="Editar">' + UI.ICONS.pencil + '</a>'
        + '<button class="btn btn--icon js-delete-prop" data-id="' + UI.esc(deleteId) + '" title="Eliminar">' + UI.ICONS.trash + '</button>';
      cardsHtml += UI.renderPropertyCard(prop, actions);
    }

    content.innerHTML = '<div class="cards-grid">' + cardsHtml + '</div>';

    // Delete handlers
    var deleteBtns = content.querySelectorAll('.js-delete-prop');
    for (var j = 0; j < deleteBtns.length; j++) {
      (function (btn) {
        btn.addEventListener('click', function () {
          var id = btn.getAttribute('data-id');
          var prop = P.getById(id);
          if (!prop) return;
          UI.showConfirm(
            'Eliminar propiedad',
            'Esta acción eliminará "' + prop.title + '" y finalizará sus contratos activos. ¿Continuar?',
            function () {
              P.remove(id);
              S.setFlash('Propiedad eliminada correctamente.', 'success');
              window.location.reload();
            },
            'Eliminar'
          );
        });
      }(deleteBtns[j]));
    }
  }

  /* ======================================================
     ADD PROPERTY
  ====================================================== */
  function initAddProperty() {
    var base = UI.getBasePath();
    var content = UI.mountShell('add-property', 'Nueva propiedad', 'Registra una propiedad en tu portafolio');
    UI.showFlash();

    var statuses = [
      { value: S.PROPERTY_STATUS.AVAILABLE,   label: 'Disponible' },
      { value: S.PROPERTY_STATUS.RENTED,      label: 'Rentada' },
      { value: S.PROPERTY_STATUS.MAINTENANCE, label: 'En mantenimiento' }
    ];

    var statusOptions = '';
    for (var i = 0; i < statuses.length; i++) {
      statusOptions += '<option value="' + UI.esc(statuses[i].value) + '">' + UI.esc(statuses[i].label) + '</option>';
    }

    content.innerHTML = UI.renderBackLink(base + 'pages/properties.html', 'Mis propiedades')
      + '<div class="form-card">'
        + '<form id="property-form" novalidate>'
          + '<div class="form-grid">'
            + '<div class="form-group form-group--full">'
              + '<label class="form-label" for="title">Título *</label>'
              + '<input class="form-input" id="title" name="title" type="text" placeholder="Ej: Apartamento Moderno Centro" autocomplete="off">'
              + '<span class="form-error" data-error="title"></span>'
            + '</div>'
            + '<div class="form-group form-group--full">'
              + '<label class="form-label" for="address">Dirección *</label>'
              + '<input class="form-input" id="address" name="address" type="text" placeholder="Ej: Av. Reforma 200, CDMX" autocomplete="off">'
              + '<span class="form-error" data-error="address"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="price">Precio mensual (MXN) *</label>'
              + '<input class="form-input" id="price" name="price" type="number" min="1" placeholder="Ej: 15000">'
              + '<span class="form-error" data-error="price"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="status">Estado *</label>'
              + '<select class="form-select" id="status" name="status">' + statusOptions + '</select>'
              + '<span class="form-error" data-error="status"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="bedrooms">Habitaciones *</label>'
              + '<input class="form-input" id="bedrooms" name="bedrooms" type="number" min="1" placeholder="Ej: 2">'
              + '<span class="form-error" data-error="bedrooms"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="bathrooms">Baños *</label>'
              + '<input class="form-input" id="bathrooms" name="bathrooms" type="number" min="1" placeholder="Ej: 1">'
              + '<span class="form-error" data-error="bathrooms"></span>'
            + '</div>'
            + '<div class="form-group form-group--full">'
              + '<label class="form-label" for="description">Descripción</label>'
              + '<textarea class="form-textarea" id="description" name="description" placeholder="Describe brevemente la propiedad..."></textarea>'
              + '<span class="form-error" data-error="description"></span>'
            + '</div>'
          + '</div>'
          + '<div class="form-actions">'
            + '<button type="submit" class="btn btn--primary">' + UI.ICONS.plus + 'Guardar propiedad</button>'
            + '<a class="btn btn--secondary" href="' + base + 'pages/properties.html">Cancelar</a>'
          + '</div>'
        + '</form>'
      + '</div>';

    var form = document.getElementById('property-form');
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      clearFormErrors(form);
      var data = getFormData(form);
      var errors = P.validate(data);
      if (errors) {
        showFormErrors(form, errors);
        return;
      }
      P.create(data);
      S.setFlash('Propiedad creada exitosamente.', 'success');
      window.location.href = base + 'pages/properties.html';
    });
  }

  /* ======================================================
     EDIT PROPERTY
  ====================================================== */
  function initEditProperty() {
    var base = UI.getBasePath();
    var id = getParam('id');
    var prop = id ? P.getById(id) : null;

    if (!prop) {
      var content = UI.mountShell('properties', 'Editar propiedad', '');
      content.innerHTML = UI.renderAlert('Propiedad no encontrada.', 'danger')
        + '<a class="btn btn--secondary" href="' + base + 'pages/properties.html">Volver</a>';
      return;
    }

    var content = UI.mountShell('properties', 'Editar propiedad', prop.title);
    UI.showFlash();

    var statuses = [
      { value: S.PROPERTY_STATUS.AVAILABLE,   label: 'Disponible' },
      { value: S.PROPERTY_STATUS.RENTED,      label: 'Rentada' },
      { value: S.PROPERTY_STATUS.MAINTENANCE, label: 'En mantenimiento' }
    ];

    var statusOptions = '';
    for (var i = 0; i < statuses.length; i++) {
      var sel = statuses[i].value === prop.status ? ' selected' : '';
      statusOptions += '<option value="' + UI.esc(statuses[i].value) + '"' + sel + '>' + UI.esc(statuses[i].label) + '</option>';
    }

    content.innerHTML = UI.renderBackLink(base + 'pages/properties.html', 'Mis propiedades')
      + '<div class="form-card">'
        + '<form id="property-form" novalidate>'
          + '<div class="form-grid">'
            + '<div class="form-group form-group--full">'
              + '<label class="form-label" for="title">Título *</label>'
              + '<input class="form-input" id="title" name="title" type="text" value="' + UI.esc(prop.title) + '" autocomplete="off">'
              + '<span class="form-error" data-error="title"></span>'
            + '</div>'
            + '<div class="form-group form-group--full">'
              + '<label class="form-label" for="address">Dirección *</label>'
              + '<input class="form-input" id="address" name="address" type="text" value="' + UI.esc(prop.address) + '" autocomplete="off">'
              + '<span class="form-error" data-error="address"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="price">Precio mensual (MXN) *</label>'
              + '<input class="form-input" id="price" name="price" type="number" min="1" value="' + UI.esc(prop.price) + '">'
              + '<span class="form-error" data-error="price"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="status">Estado *</label>'
              + '<select class="form-select" id="status" name="status">' + statusOptions + '</select>'
              + '<span class="form-error" data-error="status"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="bedrooms">Habitaciones *</label>'
              + '<input class="form-input" id="bedrooms" name="bedrooms" type="number" min="1" value="' + UI.esc(prop.bedrooms) + '">'
              + '<span class="form-error" data-error="bedrooms"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="bathrooms">Baños *</label>'
              + '<input class="form-input" id="bathrooms" name="bathrooms" type="number" min="1" value="' + UI.esc(prop.bathrooms) + '">'
              + '<span class="form-error" data-error="bathrooms"></span>'
            + '</div>'
            + '<div class="form-group form-group--full">'
              + '<label class="form-label" for="description">Descripción</label>'
              + '<textarea class="form-textarea" id="description" name="description">' + UI.esc(prop.description || '') + '</textarea>'
              + '<span class="form-error" data-error="description"></span>'
            + '</div>'
          + '</div>'
          + '<div class="form-actions">'
            + '<button type="submit" class="btn btn--primary">' + UI.ICONS.pencil + 'Guardar cambios</button>'
            + '<a class="btn btn--secondary" href="' + base + 'pages/properties.html">Cancelar</a>'
          + '</div>'
        + '</form>'
      + '</div>';

    var form = document.getElementById('property-form');
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      clearFormErrors(form);
      var data = getFormData(form);
      var errors = P.validate(data);
      if (errors) {
        showFormErrors(form, errors);
        return;
      }
      P.update(id, data);
      S.setFlash('Propiedad actualizada correctamente.', 'success');
      window.location.href = base + 'pages/properties.html';
    });
  }

  /* ======================================================
     RENT PROPERTY
  ====================================================== */
  function initRentProperty() {
    var base = UI.getBasePath();
    var content = UI.mountShell('rent-property', 'Registrar renta', 'Crea un nuevo contrato de arrendamiento');
    UI.showFlash();

    var props   = P.getAll();
    var tenants = T.getAll();

    // Only show available properties
    var availableProps = [];
    for (var i = 0; i < props.length; i++) {
      if (props[i].status === S.PROPERTY_STATUS.AVAILABLE) availableProps.push(props[i]);
    }

    if (!availableProps.length) {
      content.innerHTML = UI.renderAlert('No hay propiedades disponibles para rentar en este momento.', 'warning')
        + '<a class="btn btn--secondary" href="' + base + 'pages/properties.html">Ver propiedades</a>';
      return;
    }

    if (!tenants.length) {
      content.innerHTML = UI.renderAlert('No hay inquilinos registrados. Agrega uno primero.', 'warning')
        + '<a class="btn btn--primary" href="' + base + 'pages/add-tenant.html">' + UI.ICONS.plus + 'Nuevo inquilino</a>';
      return;
    }

    var propOptions = '<option value="">-- Selecciona una propiedad --</option>';
    for (var p = 0; p < availableProps.length; p++) {
      propOptions += '<option value="' + UI.esc(availableProps[p].id) + '">'
        + UI.esc(availableProps[p].title) + ' — ' + UI.formatPrice(availableProps[p].price) + '/mes'
        + '</option>';
    }

    var tenantOptions = '<option value="">-- Selecciona un inquilino --</option>';
    for (var tt = 0; tt < tenants.length; tt++) {
      tenantOptions += '<option value="' + UI.esc(tenants[tt].id) + '">' + UI.esc(tenants[tt].name) + '</option>';
    }

    var contractStatuses = [
      { value: S.CONTRACT_STATUS.ACTIVE,  label: 'Activo' },
      { value: S.CONTRACT_STATUS.PENDING, label: 'Pendiente' }
    ];
    var contractStatusOptions = '';
    for (var cs = 0; cs < contractStatuses.length; cs++) {
      contractStatusOptions += '<option value="' + UI.esc(contractStatuses[cs].value) + '">' + UI.esc(contractStatuses[cs].label) + '</option>';
    }

    // Default dates
    var today = new Date();
    var nextYear = new Date(today);
    nextYear.setFullYear(nextYear.getFullYear() + 1);
    function padDate(d) { return d < 10 ? '0' + d : String(d); }
    var defaultStart = today.getFullYear() + '-' + padDate(today.getMonth() + 1) + '-' + padDate(today.getDate());
    var defaultEnd   = nextYear.getFullYear() + '-' + padDate(nextYear.getMonth() + 1) + '-' + padDate(nextYear.getDate());

    content.innerHTML = UI.renderBackLink(base + 'pages/properties.html', 'Mis propiedades')
      + '<div class="form-card">'
        + '<form id="rental-form" novalidate>'
          + '<div class="form-grid">'
            + '<div class="form-group form-group--full">'
              + '<label class="form-label" for="propertyId">Propiedad *</label>'
              + '<select class="form-select" id="propertyId" name="propertyId">' + propOptions + '</select>'
              + '<span class="form-error" data-error="propertyId"></span>'
            + '</div>'
            + '<div class="form-group form-group--full">'
              + '<label class="form-label" for="tenantId">Inquilino *</label>'
              + '<select class="form-select" id="tenantId" name="tenantId">' + tenantOptions + '</select>'
              + '<span class="form-error" data-error="tenantId"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="startDate">Fecha de inicio *</label>'
              + '<input class="form-input" id="startDate" name="startDate" type="date" value="' + defaultStart + '">'
              + '<span class="form-error" data-error="startDate"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="endDate">Fecha de fin *</label>'
              + '<input class="form-input" id="endDate" name="endDate" type="date" value="' + defaultEnd + '">'
              + '<span class="form-error" data-error="endDate"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="rentAmount">Monto de renta (MXN) *</label>'
              + '<input class="form-input" id="rentAmount" name="rentAmount" type="number" min="1" placeholder="Ej: 15000">'
              + '<span class="form-error" data-error="rentAmount"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="contractStatus">Estado del contrato</label>'
              + '<select class="form-select" id="contractStatus" name="contractStatus">' + contractStatusOptions + '</select>'
              + '<span class="form-error" data-error="contractStatus"></span>'
            + '</div>'
          + '</div>'
          + '<div class="form-actions">'
            + '<button type="submit" class="btn btn--primary">' + UI.ICONS.key + 'Registrar renta</button>'
            + '<a class="btn btn--secondary" href="' + base + 'pages/properties.html">Cancelar</a>'
          + '</div>'
        + '</form>'
      + '</div>';

    // Auto-fill rent amount from selected property
    var propSelect = document.getElementById('propertyId');
    var amountInput = document.getElementById('rentAmount');
    propSelect.addEventListener('change', function () {
      var selectedId = propSelect.value;
      for (var k = 0; k < availableProps.length; k++) {
        if (availableProps[k].id === selectedId) {
          amountInput.value = availableProps[k].price;
          break;
        }
      }
    });

    var form = document.getElementById('rental-form');
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      clearFormErrors(form);
      var data = getFormData(form);
      var errors = R.validate(data);
      if (errors) {
        showFormErrors(form, errors);
        return;
      }
      R.create(data);
      S.setFlash('Contrato de renta registrado exitosamente.', 'success');
      window.location.href = base + 'pages/properties.html';
    });
  }

  /* ======================================================
     TENANTS LIST
  ====================================================== */
  function initTenants() {
    var base = UI.getBasePath();
    var addBtn = '<a class="btn btn--primary" href="' + base + 'pages/add-tenant.html">' + UI.ICONS.plus + 'Nuevo inquilino</a>';
    var content = UI.mountShell('properties', 'Inquilinos', 'Gestiona tu lista de inquilinos', addBtn);
    UI.showFlash();

    var tenants = T.getAll();

    if (!tenants.length) {
      content.innerHTML = UI.renderEmptyState('users', 'Sin inquilinos', 'Aún no hay inquilinos registrados.',
        '<a class="btn btn--primary" href="' + base + 'pages/add-tenant.html">' + UI.ICONS.plus + 'Nuevo inquilino</a>');
      return;
    }

    var rows = '';
    for (var i = 0; i < tenants.length; i++) {
      var t = tenants[i];
      var editHref = base + 'pages/edit-tenant.html?id=' + t.id;
      rows += '<tr>'
        + '<td><strong>' + UI.esc(t.name) + '</strong></td>'
        + '<td>' + UI.esc(t.email) + '</td>'
        + '<td>' + UI.esc(t.phone) + '</td>'
        + '<td>' + UI.esc(t.documentId) + '</td>'
        + '<td>'
          + '<div style="display:flex;gap:6px">'
            + '<a class="btn btn--icon btn--sm" href="' + UI.esc(editHref) + '" title="Editar">' + UI.ICONS.pencil + '</a>'
            + '<button class="btn btn--icon btn--sm js-delete-tenant" data-id="' + UI.esc(t.id) + '" title="Eliminar">' + UI.ICONS.trash + '</button>'
          + '</div>'
        + '</td>'
      + '</tr>';
    }

    content.innerHTML = '<div class="table-card">'
      + '<div class="table-card__header"><div class="table-card__title">Lista de inquilinos</div></div>'
      + '<div style="overflow-x:auto">'
        + '<table class="table">'
          + '<thead><tr>'
            + '<th>Nombre</th><th>Email</th><th>Teléfono</th><th>Documento</th><th>Acciones</th>'
          + '</tr></thead>'
          + '<tbody>' + rows + '</tbody>'
        + '</table>'
      + '</div>'
    + '</div>';

    var deleteBtns = content.querySelectorAll('.js-delete-tenant');
    for (var j = 0; j < deleteBtns.length; j++) {
      (function (btn) {
        btn.addEventListener('click', function () {
          var id = btn.getAttribute('data-id');
          var tenant = T.getById(id);
          if (!tenant) return;
          UI.showConfirm(
            'Eliminar inquilino',
            '¿Deseas eliminar a "' + tenant.name + '"? Esta acción no se puede deshacer.',
            function () {
              T.remove(id);
              S.setFlash('Inquilino eliminado correctamente.', 'success');
              window.location.reload();
            },
            'Eliminar'
          );
        });
      }(deleteBtns[j]));
    }
  }

  /* ======================================================
     ADD TENANT
  ====================================================== */
  function initAddTenant() {
    var base = UI.getBasePath();
    var content = UI.mountShell('properties', 'Nuevo inquilino', 'Registra un inquilino');
    UI.showFlash();

    content.innerHTML = UI.renderBackLink(base + 'pages/tenants.html', 'Inquilinos')
      + '<div class="form-card">'
        + '<form id="tenant-form" novalidate>'
          + '<div class="form-grid">'
            + '<div class="form-group form-group--full">'
              + '<label class="form-label" for="name">Nombre completo *</label>'
              + '<input class="form-input" id="name" name="name" type="text" placeholder="Ej: Juan Pérez García" autocomplete="off">'
              + '<span class="form-error" data-error="name"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="email">Email *</label>'
              + '<input class="form-input" id="email" name="email" type="email" placeholder="juan@email.com">'
              + '<span class="form-error" data-error="email"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="phone">Teléfono *</label>'
              + '<input class="form-input" id="phone" name="phone" type="tel" placeholder="55-1234-5678">'
              + '<span class="form-error" data-error="phone"></span>'
            + '</div>'
            + '<div class="form-group form-group--full">'
              + '<label class="form-label" for="documentId">Documento de identidad *</label>'
              + '<input class="form-input" id="documentId" name="documentId" type="text" placeholder="Ej: PEGJ900101" autocomplete="off">'
              + '<span class="form-error" data-error="documentId"></span>'
            + '</div>'
            + '<div class="form-group form-group--full">'
              + '<label class="form-label" for="notes">Notas</label>'
              + '<textarea class="form-textarea" id="notes" name="notes" placeholder="Observaciones adicionales..."></textarea>'
              + '<span class="form-error" data-error="notes"></span>'
            + '</div>'
          + '</div>'
          + '<div class="form-actions">'
            + '<button type="submit" class="btn btn--primary">' + UI.ICONS.plus + 'Guardar inquilino</button>'
            + '<a class="btn btn--secondary" href="' + base + 'pages/tenants.html">Cancelar</a>'
          + '</div>'
        + '</form>'
      + '</div>';

    var form = document.getElementById('tenant-form');
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      clearFormErrors(form);
      var data = getFormData(form);
      var errors = T.validate(data);
      if (errors) {
        showFormErrors(form, errors);
        return;
      }
      T.create(data);
      S.setFlash('Inquilino registrado exitosamente.', 'success');
      window.location.href = base + 'pages/tenants.html';
    });
  }

  /* ======================================================
     EDIT TENANT
  ====================================================== */
  function initEditTenant() {
    var base = UI.getBasePath();
    var id = getParam('id');
    var tenant = id ? T.getById(id) : null;

    if (!tenant) {
      var content = UI.mountShell('properties', 'Editar inquilino', '');
      content.innerHTML = UI.renderAlert('Inquilino no encontrado.', 'danger')
        + '<a class="btn btn--secondary" href="' + base + 'pages/tenants.html">Volver</a>';
      return;
    }

    var content = UI.mountShell('properties', 'Editar inquilino', tenant.name);
    UI.showFlash();

    content.innerHTML = UI.renderBackLink(base + 'pages/tenants.html', 'Inquilinos')
      + '<div class="form-card">'
        + '<form id="tenant-form" novalidate>'
          + '<div class="form-grid">'
            + '<div class="form-group form-group--full">'
              + '<label class="form-label" for="name">Nombre completo *</label>'
              + '<input class="form-input" id="name" name="name" type="text" value="' + UI.esc(tenant.name) + '" autocomplete="off">'
              + '<span class="form-error" data-error="name"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="email">Email *</label>'
              + '<input class="form-input" id="email" name="email" type="email" value="' + UI.esc(tenant.email) + '">'
              + '<span class="form-error" data-error="email"></span>'
            + '</div>'
            + '<div class="form-group">'
              + '<label class="form-label" for="phone">Teléfono *</label>'
              + '<input class="form-input" id="phone" name="phone" type="tel" value="' + UI.esc(tenant.phone) + '">'
              + '<span class="form-error" data-error="phone"></span>'
            + '</div>'
            + '<div class="form-group form-group--full">'
              + '<label class="form-label" for="documentId">Documento de identidad *</label>'
              + '<input class="form-input" id="documentId" name="documentId" type="text" value="' + UI.esc(tenant.documentId) + '" autocomplete="off">'
              + '<span class="form-error" data-error="documentId"></span>'
            + '</div>'
            + '<div class="form-group form-group--full">'
              + '<label class="form-label" for="notes">Notas</label>'
              + '<textarea class="form-textarea" id="notes" name="notes">' + UI.esc(tenant.notes || '') + '</textarea>'
              + '<span class="form-error" data-error="notes"></span>'
            + '</div>'
          + '</div>'
          + '<div class="form-actions">'
            + '<button type="submit" class="btn btn--primary">' + UI.ICONS.pencil + 'Guardar cambios</button>'
            + '<a class="btn btn--secondary" href="' + base + 'pages/tenants.html">Cancelar</a>'
          + '</div>'
        + '</form>'
      + '</div>';

    var form = document.getElementById('tenant-form');
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      clearFormErrors(form);
      var data = getFormData(form);
      var errors = T.validate(data);
      if (errors) {
        showFormErrors(form, errors);
        return;
      }
      T.update(id, data);
      S.setFlash('Inquilino actualizado correctamente.', 'success');
      window.location.href = base + 'pages/tenants.html';
    });
  }

  /* ===== BOOTSTRAP ===== */
  function init() {
    S.init();
    var page = getCurrentPage();
    var handler = ROUTES[page];
    if (handler) {
      handler();
    } else {
      initDashboard();
    }
  }

  document.addEventListener('DOMContentLoaded', init);

  window.RealtorApp = { init: init };

}());
