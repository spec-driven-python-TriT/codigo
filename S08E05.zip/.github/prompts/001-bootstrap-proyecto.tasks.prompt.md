----
name: 001-bootstrap-proyecto-tasks
---

/speckit.tasks
Descompón el plan de 001-bootstrap-proyecto en tareas secuenciales,
accionables y verificables. Agrupa por fases del plan.md.
Numera con formato T<fase>.<orden>: T1.1, T1.2, T2.1, etc.
Idioma: español.