----
name: 001-bootstrap-proyecto-analize
---

/speckit.analyze

Audita la consistencia de la spec 001-bootstrap-proyecto.

Archivos a revisar:
- .specify/specs/001-bootstrap-proyecto/spec.md
- .specify/specs/001-bootstrap-proyecto/plan.md

Emite un reporte con tres niveles de severidad:
- CRÍTICO: debe corregirse antes de /speckit.tasks
- ADVERTENCIA: debería atenderse o documentarse
- SUGERENCIA: considerar para iteraciones futuras

No edites archivos. Solo emite el reporte.
Idioma: español.