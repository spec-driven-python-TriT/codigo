# Tasks: 001-bootstrap-proyecto

**Entrada**: Artefactos de diseño en `/specs/001-bootstrap-proyecto/`  
**Prerequisitos**: `plan.md`, `spec.md`, `research.md`, `data-model.md`, `contracts/`

## Formato

- `[ ]` tarea pendiente, `[X]` tarea completada.
- Identificador obligatorio por fase: `T<fase>.<orden>` (ejemplo: `T1.1`, `T3.4`).
- Cada tarea incluye ruta(s) de archivo para que sea accionable y verificable.

## Fase 1: Setup del Proyecto

**Objetivo**: Dejar la estructura mínima del repositorio y la base de dependencias listas para arrancar.

- [ ] **T1.1** Crear estructura base del proyecto en `app/`, `app/modules/`, `app/static/`, `app/templates/`, `alembic/` y `tests/` conforme a RF-001.
- [ ] **T1.2** Definir dependencias de producción y desarrollo con rangos `~=` en `pyproject.toml` (RF-018).
- [ ] **T1.3** Crear `app/__init__.py` y `app/main.py` con instancia inicial de FastAPI y montaje de rutas base.
- [ ] **T1.4** Crear `.env.example` con `DATABASE_URL`, `DATABASE_URL_DIRECT`, `APP_ENV`, `LOG_LEVEL` y valores de ejemplo seguros.
- [ ] **T1.5** Actualizar `README.md` con pasos mínimos de arranque (`uv sync`, `uv run uvicorn ...`, `alembic upgrade head`) en español.

**Checkpoint Fase 1**: El repositorio puede sincronizar dependencias con `uv sync` sin errores (CE-001).

---

## Fase 2: Fundación Técnica Bloqueante

**Objetivo**: Implementar configuración, base de datos async, migraciones y calidad estática; bloquea historias de usuario.

- [ ] **T2.1** Implementar `Settings` tipado con `pydantic-settings` en `app/config.py` (frozen, carga desde `.env`, fallos tempranos por variables faltantes) según RF-002.
- [ ] **T2.2** Implementar engine runtime async y `async_sessionmaker` en `app/database.py` con `statement_cache_size=0`, `prepared_statement_cache_size=0`, `ssl=require` y `pool_pre_ping=True` (RF-003).
- [ ] **T2.3** Exponer dependencia `get_session` en `app/database.py` retornando `AsyncSession` por request (RF-004).
- [ ] **T2.4** Configurar Alembic async en `alembic/env.py` para usar `DATABASE_URL_DIRECT` exclusivamente en migraciones (RF-005).
- [ ] **T2.5** Crear migración baseline `alembic/versions/0001_baseline.py` que habilite `pgcrypto` y documente `gen_random_uuid()` (RF-006).
- [ ] **T2.6** Configurar Ruff en `pyproject.toml` con `target-version=py313`, `line-length=88` y reglas `E,F,I,B,UP,ASYNC` (RF-015).
- [ ] **T2.7** Configurar mypy estricto para `app/modules/` en `pyproject.toml` (RF-016).
- [ ] **T2.8** Configurar `pytest-asyncio` con `asyncio_mode = "auto"` en `pyproject.toml` (RF-017).
- [ ] **T2.9** Implementar pruebas de sanidad de infraestructura en `tests/test_config.py` para validar error temprano cuando faltan `DATABASE_URL` o `DATABASE_URL_DIRECT`.
- [ ] **T2.10** Ejecutar y verificar `uv run alembic upgrade head` usando conexión directa y documentar resultado en `specs/001-bootstrap-proyecto/quickstart.md` (CE-007).

**Checkpoint Fase 2**: Infraestructura lista; se habilita trabajo de historias US1/US2/US3.

---

## Fase 3: US1 - Arranque técnico verificable del sistema (Prioridad P1)

**Objetivo**: Exponer salud de app+DB con comportamiento correcto en éxito y falla.

**Prueba independiente**: `GET /health` devuelve `200 {"app":"ok","db":"ok"}` con DB disponible y `503 {"app":"ok","db":"down"}` cuando falla conexión.

### Pruebas US1

- [ ] **T3.1** Crear `tests/test_health.py::test_health_ok` con `httpx.AsyncClient` y sesión mockeada para rama exitosa (contrato `contracts/health.md`).
- [ ] **T3.2** Crear `tests/test_health.py::test_health_db_down` con sesión mockeada que lance excepción para validar `503` y body esperado.

### Implementación US1

- [ ] **T3.3** Definir esquema de respuesta `EstadoSalud` (Pydantic v2 frozen) en `app/main.py` o en módulo dedicado reutilizable (RF-007).
- [ ] **T3.4** Implementar handler async `GET /health` en `app/main.py` con `SELECT 1` vía `AsyncSession` y mapping de estados según contrato.
- [ ] **T3.5** Implementar logging estructurado solo en error DB (`event="health.db_down"`) sin exponer secretos (clarificación 7).
- [ ] **T3.6** Verificar contrato HTTP de `GET /health` respecto a `specs/001-bootstrap-proyecto/contracts/health.md`.

**Checkpoint Fase 3**: US1 funcional y verificable de forma independiente.

---

## Fase 4: US2 - Base visual fundacional reutilizable (Prioridad P2)

**Objetivo**: Entregar dashboard inicial renderizado por servidor con layout, componentes e iconografía local.

**Prueba independiente**: `GET /` renderiza sidebar + navbar + 3 tarjetas métricas, con SVG inline y comportamiento responsive bajo 1024px.

### Pruebas US2

- [ ] **T4.1** Crear `tests/test_dashboard.py::test_dashboard_renderiza_estructura` verificando status 200, sidebar, navbar y 3 tarjetas (`contracts/dashboard.md`).
- [ ] **T4.2** Crear `tests/test_dashboard.py::test_dashboard_iconos_inline` verificando presencia de `<svg` y ausencia de webfonts/icon tags.

### Implementación US2

- [ ] **T4.3** Crear `app/templates/base.html` con layout base (sidebar fija, área principal, zona flash y carga local de `app/static/vendor/htmx.min.js`) según RF-010 y RF-012.
- [ ] **T4.4** Crear macro `icon(nombre, size, class)` en `app/templates/macros/icons.html` para render SVG inline desde `app/static/icons/` (RF-013).
- [ ] **T4.5** Incorporar 13 iconos Lucide outline requeridos en `app/static/icons/` con nombres exactos de RF-011.
- [ ] **T4.6** Crear componentes estructurales en `app/templates/components/`: `_sidebar.html`, `_navbar.html`, `_card_propiedad.html`, `_tarjeta_metrica.html`, `_accesos_rapidos.html`, `_badge_estado.html`, `_form_field.html`, `_alerta.html` (RF-014).
- [ ] **T4.7** Crear `app/templates/index.html` con dashboard demo y exactamente 3 métricas hardcoded: Propiedades activas, Contratos vigentes, Ingresos del mes (clarificación 3).
- [ ] **T4.8** Implementar `GET /` en `app/main.py` para renderizar `index.html` y emitir logging solo en error (`event="dashboard.error"`).
- [ ] **T4.9** Crear `app/static/css/app.css` con tokens en `:root` y siete secciones comentadas (reset, variables, tipografía, layout, componentes, utilidades, responsive) según RF-009.
- [ ] **T4.10** Implementar comportamiento responsive de sidebar para 1024px y 640px en `app/static/css/app.css` y script mínimo en `app/templates/base.html`.

**Checkpoint Fase 4**: US2 funcional y verificable de forma independiente.

---

## Fase 5: US3 - Calidad estática y gobernanza del repositorio (Prioridad P3)

**Objetivo**: Asegurar gobernanza técnica inicial y cumplimiento de calidad/documentación.

**Prueba independiente**: Ruff, mypy y pytest ejecutan correctamente; contenido narrativo `.md` en español.

### Pruebas y validación US3

- [ ] **T5.1** Ejecutar `uv run ruff check .` y corregir hallazgos hasta terminar en verde (CE-008).
- [ ] **T5.2** Ejecutar `uv run ruff format --check .` y ajustar formato hasta terminar en verde (CE-008).
- [ ] **T5.3** Ejecutar `uv run mypy --strict app/modules/` y corregir errores hasta terminar en verde (CE-009).
- [ ] **T5.4** Ejecutar `uv run pytest` y asegurar aprobación de `tests/test_health.py` y `tests/test_dashboard.py`.
- [ ] **T5.5** Revisar archivos `.md` del repositorio (`README.md`, `.specify/**/*.md`, `.github/**/*.md`) para validar redacción en español (CE-010).

### Implementación US3

- [ ] **T5.6** Ajustar comentarios/docstrings en `app/**/*.py` para mantener español consistente (RF-020).
- [ ] **T5.7** Verificar que no se introducen módulos fuera de alcance en `app/modules/` (sin dominio, auth ni storage) conforme RF-019.

**Checkpoint Fase 5**: US3 funcional y criterios de calidad/gobernanza cumplidos.

---

## Fase 6: Cierre y Verificación Integral

**Objetivo**: Confirmar cumplimiento de criterios de éxito de extremo a extremo.

- [ ] **T6.1** Ejecutar flujo completo de quickstart en orden: `uv sync`, `uv run alembic upgrade head`, `uv run uvicorn app.main:app --reload`, verificación manual de `/health` y `/` (CE-001..CE-007).
- [ ] **T6.2** Validar visualmente comportamiento responsive bajo 1024px y 640px en dashboard (CE-005).
- [ ] **T6.3** Confirmar disponibilidad de los 13 SVG locales requeridos en `app/static/icons/` y su uso inline en renderizado (CE-006).
- [ ] **T6.4** Actualizar `specs/001-bootstrap-proyecto/quickstart.md` con cualquier ajuste final detectado durante validación.

---

## Dependencias y Orden de Ejecución

- Fase 1 → Fase 2 → Fases 3 y 4 → Fase 5 → Fase 6.
- US1 (Fase 3) depende de Fase 2.
- US2 (Fase 4) depende de Fase 2.
- US3 (Fase 5) depende de Fases 3 y 4 para validar calidad de todo lo implementado.
- El criterio MVP se cumple al finalizar Fase 3 (US1).

## Estrategia de Entrega Incremental

1. Completar Fases 1 y 2 para habilitar infraestructura.
2. Entregar US1 (Fase 3) y validar endpoint de salud como primer incremento.
3. Entregar US2 (Fase 4) para habilitar base visual reutilizable.
4. Consolidar con US3 (Fase 5) y cierre integral (Fase 6).