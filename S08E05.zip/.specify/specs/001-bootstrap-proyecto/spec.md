# Especificación de Feature: Bootstrap del Proyecto Realtor

**Rama de feature**: `001-bootstrap-proyecto`  
**Fecha de creación**: 2026-05-13  
**Estado**: Aprobada  
**Entrada**: Descripción de usuario: "Crea la spec 001-bootstrap-proyecto para dejar el esqueleto técnico y visual del sistema Realtor listo para la spec 002."

## Escenarios de usuario y pruebas *(obligatorio)*

### Historia de usuario 1 - Arranque técnico verificable del sistema (Prioridad: P1)

Como equipo de desarrollo, queremos arrancar la aplicación FastAPI con configuración y conexión asíncrona a base de datos ya integradas, para tener una base ejecutable, verificable y lista para evolucionar por módulos.

**Por qué esta prioridad**: Sin un arranque técnico estable (configuración, sesión async, salud de DB y migraciones), no existe base confiable para desarrollar ningún módulo de dominio posterior.

**Prueba independiente**: Puede validarse ejecutando sincronización de dependencias, arranque del servidor, endpoint `/health` con `SELECT 1` asíncrono y migración baseline con Alembic en modo async contra conexión directa.

**Escenarios de aceptación**:

1. **Dado** un entorno con `.env` válido para Supabase, **cuando** se ejecuta la aplicación, **entonces** el endpoint `/health` responde `200` con estado de aplicación y base de datos en `ok`.
2. **Dado** la configuración de Alembic async, **cuando** se ejecuta `alembic upgrade head`, **entonces** la migración baseline se aplica sin errores usando `DATABASE_URL_DIRECT`.

---

### Historia de usuario 2 - Base visual fundacional reutilizable (Prioridad: P2)

Como equipo de producto, queremos un layout base con sidebar, navbar, componentes y sistema de iconos SVG local, para construir rápidamente pantallas futuras con consistencia visual y sin dependencias externas en runtime.

**Por qué esta prioridad**: El valor de la spec 001 incluye una base visual concreta para acelerar las siguientes slices; sin esta base, la spec 002 tendría que rehacer infraestructura de UI.

**Prueba independiente**: Puede validarse renderizando `/` con dashboard demo, verificando 3 tarjetas de métrica, sidebar visible en escritorio, comportamiento colapsable bajo 1024px y uso de iconos SVG inline desde archivos locales.

**Escenarios de aceptación**:

1. **Dado** la plantilla base y componentes estructurales, **cuando** un usuario navega a `/`, **entonces** visualiza sidebar, navbar y 3 tarjetas de métrica con datos hardcoded.
2. **Dado** un viewport menor a 1024px, **cuando** se carga la página principal, **entonces** la sidebar puede colapsarse sin romper el layout principal.

---

### Historia de usuario 3 - Calidad estática y gobernanza del repositorio (Prioridad: P3)

Como equipo técnico, queremos reglas de lint, type-check y configuración async definidas desde el inicio, para evitar deuda técnica temprana y asegurar consistencia con la constitución del proyecto.

**Por qué esta prioridad**: Garantiza mantenibilidad desde la primera spec y reduce retrabajo al introducir módulos de dominio.

**Prueba independiente**: Puede validarse ejecutando Ruff, Mypy estricto sobre `app/modules/` y configuración de pytest-asyncio en modo `auto`.

**Escenarios de aceptación**:

1. **Dado** la configuración de calidad en `pyproject.toml`, **cuando** se ejecutan lint/format/type-check, **entonces** no se reportan errores de configuración.
2. **Dado** el repositorio documental, **cuando** se revisan los archivos `.md`, **entonces** todo el contenido está redactado en español.

---

## Casos límite

- ¿Qué ocurre si falta `DATABASE_URL` o `DATABASE_URL_DIRECT` en `.env`? El sistema debe fallar de forma explícita y temprana en el arranque/configuración.
- ¿Qué ocurre si la base de datos no está disponible al invocar `/health`? Debe responder con estado de app y error de DB controlado (sin filtrar secretos) o con indicador de DB no saludable.
- ¿Qué ocurre si el navegador no tiene JavaScript activo? El layout principal debe seguir siendo navegable en su estructura base (degradación aceptable en la interacción de colapso).
- ¿Qué ocurre si faltan íconos SVG requeridos en `app/static/icons/`? El componente de iconos debe manejar el caso sin romper renderizado completo de la vista.
- ¿Qué ocurre si se intenta usar pooler de transacciones para migraciones? Debe documentarse y configurarse explícitamente que Alembic usa `DATABASE_URL_DIRECT`.

## Requisitos *(obligatorio)*

### Requisitos funcionales

- **RF-001**: El sistema DEBE crear la estructura base del proyecto con `app/__init__.py`, `app/main.py`, `app/config.py`, `app/database.py`, `app/modules/`, `app/static/`, `app/templates/` y `alembic/` en modo async.
- **RF-002**: El sistema DEBE exponer configuración mediante `pydantic-settings` leyendo `.env` y publicando `DATABASE_URL`, `DATABASE_URL_DIRECT`, `APP_ENV` y `LOG_LEVEL`.
- **RF-003**: El sistema DEBE crear un `AsyncEngine` para runtime con Supabase transaction pooler y configurar `statement_cache_size=0`, `prepared_statement_cache_size=0` y SSL requerido.
- **RF-004**: El sistema DEBE exponer una dependencia `get_session` que entregue `AsyncSession` por request.
- **RF-005**: El sistema DEBE configurar Alembic async para leer `DATABASE_URL_DIRECT` (conexión directa) durante migraciones.
- **RF-006**: El sistema DEBE incluir y aplicar una migración baseline sin errores contra Supabase.
- **RF-007**: El sistema DEBE implementar `GET /health` con verificación de aplicación y base de datos mediante `SELECT 1` asíncrono.
- **RF-008**: El sistema DEBE implementar `GET /` que renderice un dashboard demo con sidebar, navbar y 3 tarjetas métricas hardcoded.
- **RF-009**: El sistema DEBE incluir `app/static/css/app.css` con tokens de diseño en `:root` y siete secciones comentadas: reset, variables, tipografía, layout, componentes, utilidades y responsive.
- **RF-010**: El sistema DEBE vendorear `htmx.min.js` en `app/static/vendor/` y NO DEBE cargar HTMX desde CDN en runtime.
- **RF-011**: El sistema DEBE incluir 13 iconos Lucide outline en `app/static/icons/`: `layout-dashboard`, `building-2`, `users`, `file-text`, `wallet`, `wrench`, `settings`, `menu`, `x`, `check-circle-2`, `alert-triangle`, `alert-circle`, `info`.
- **RF-012**: El sistema DEBE definir `app/templates/base.html` con layout de sidebar fija, área principal y zona flash.
- **RF-013**: El sistema DEBE incluir `app/templates/macros/icons.html` con macro `icon(nombre, size, class)` para renderizado inline de SVG.
- **RF-014**: El sistema DEBE crear los componentes estructurales: `_sidebar.html`, `_navbar.html`, `_card_propiedad.html`, `_tarjeta_metrica.html`, `_accesos_rapidos.html`, `_badge_estado.html`, `_form_field.html`, `_alerta.html`.
- **RF-015**: El sistema DEBE configurar Ruff en `pyproject.toml` con target Python 3.13, line-length 88 y reglas `E`, `F`, `I`, `B`, `UP`, `ASYNC`.
- **RF-016**: El sistema DEBE configurar Mypy en modo `--strict` para `app/modules/`.
- **RF-017**: El sistema DEBE configurar `pytest-asyncio` con `asyncio_mode = "auto"`.
- **RF-018**: El sistema DEBE declarar dependencias de producción y desarrollo con rangos `~=` según el alcance definido para esta spec.
- **RF-019**: El sistema NO DEBE introducir módulos de dominio, autenticación ni storage de archivos en esta spec.
- **RF-020**: El sistema DEBE mantener documentación, comentarios y docstrings en español.

### Entidades clave *(si aplica a datos)*

- **ConfiguraciónAplicación**: representación tipada de variables de entorno operativas (`DATABASE_URL`, `DATABASE_URL_DIRECT`, `APP_ENV`, `LOG_LEVEL`) para bootstrap.
- **EstadoSalud**: contrato de respuesta del endpoint de salud que expresa estado de aplicación y disponibilidad de base de datos.
- **MétricaDashboard**: estructura de datos hardcoded para tarjetas visuales iniciales del dashboard.

## Criterios de éxito *(obligatorio)*

### Resultados medibles

- **CE-001**: El equipo puede ejecutar `uv sync` con instalación completa de dependencias sin errores.
- **CE-002**: El servidor inicia con `uv run uvicorn app.main:app --reload` sin fallos de importación ni configuración.
- **CE-003**: `GET /health` responde `200` con payload equivalente a estado de app y DB en `ok` cuando la base está disponible.
- **CE-004**: `GET /` renderiza dashboard con sidebar y exactamente 3 tarjetas de métrica visibles.
- **CE-005**: Bajo 1024px, la sidebar se comporta de forma colapsable preservando usabilidad del contenido principal.
- **CE-006**: Los 13 íconos requeridos están disponibles como SVG inline provenientes de archivos locales en `app/static/icons/`.
- **CE-007**: `alembic upgrade head` aplica baseline sin errores contra Supabase usando conexión directa.
- **CE-008**: `uv run ruff check .` y `uv run ruff format --check .` finalizan sin hallazgos.
- **CE-009**: `uv run mypy --strict app/modules/` finaliza sin errores.
- **CE-010**: Todo el contenido narrativo de los archivos `.md` del repo está en español. Se aceptan como excepciones: nombres de tecnologías (FastAPI, SQLAlchemy, HTMX, Jinja2, etc.), rutas de archivos (app/main.py, .specify/, etc.), comandos de terminal (uv sync, alembic upgrade head, etc.) e identificadores técnicos (DATABASE_URL, get_session, etc.). No se aceptan párrafos, descripciones ni comentarios en inglés.

## Supuestos



# Clarificaciones

Las siguientes decisiones fueron tomadas tras el proceso de clarificación interactivo:

1. **Breakpoints responsive sidebar:** Dos breakpoints, 1024px (desktop/tablet) y 640px (móvil).
2. **GET /health cuando la DB falla:** HTTP 503, JSON {"db": "down"}.
3. **Tarjetas de métrica:** Propiedades activas, Contratos vigentes, Ingresos del mes (iconos: building-2, file-text, wallet).
4. **Componentes estructurales:** HTML + CSS completo, visualmente funcional.
5. **SVG Lucide:** Generados inline por el agente desde el repo oficial.
6. **Migración baseline:** Incluir pgcrypto y habilitar gen_random_uuid().
7. **Logging en /health y /**: Solo en caso de error.
